"""
Test script for language detector to verify dub/sub classification
"""

from Backend.helper.language_detector import detect_languages, is_dub, is_sub, analyze_filename

# Test cases
test_filenames = [
    # Japanese only (should be SUB - original with subtitles)
    "[SubsPlease] Hunter x Hunter - 01 (1080p) [Japanese].mkv",
    "Naruto - 01 [Japanese][1080p].mp4",
    "[Erai-raws] One Piece - 500 [JP][1080p].mkv",
    "[animeshrine.xyz] S01E01 Golden Kamuy 480p Japanese.mkv",
    
    # Japanese + Hindi (should be DUB - dual audio)
    "[Anime] Hunter x Hunter - 01 [Japanese+Hindi] [1080p].mkv",
    "Naruto Shippuden E500 [Jpn+Hin] 720p.mp4",
    "[animeshrine.xyz] S01E10 Golden Kamuy 480p Japanese, Hindi.mkv",
    
    # Japanese + English (should be DUB - dual audio)
    "[SubsPlease] Hunter x Hunter - 01 [Japanese+English] [1080p].mkv",
    "One Piece E01 [Jpn+Eng] [720p].mkv",
    "[animeshrine.xyz] S01E10 Golden Kamuy 480p Japanese, English.mkv",
    
    # Japanese + Hindi + English (should be DUB - multi audio)
    "Hunter x Hunter - 01 [Japanese+English+Hindi] [1080p].mkv",
    
    # English only (should be SUB - no Japanese)
    "Hunter x Hunter - 01 [English] [1080p].mkv",
    "Naruto - 01 [Eng] [720p].mp4",
    
    # Hindi only (should be SUB - no Japanese)
    "Hunter x Hunter - 01 [Hindi] [1080p].mkv",
    "Naruto - 01 [Hin] [720p].mp4",
]

print("=" * 80)
print("LANGUAGE DETECTION TEST")
print("=" * 80)

for filename in test_filenames:
    result = analyze_filename(filename)
    print(f"\nFilename: {filename}")
    print(f"  Detected languages: {result['languages']}")
    print(f"  Is DUB: {result['is_dub']}")
    print(f"  Is SUB: {result['is_sub']}")
    print(f"  Classification: {'🎙️ DUB' if result['is_dub'] else '📝 SUB'}")

print("\n" + "=" * 80)
print("TEST COMPLETED")
print("=" * 80)
