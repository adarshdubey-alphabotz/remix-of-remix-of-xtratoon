from logging import FileHandler, StreamHandler, INFO, ERROR, Formatter, basicConfig, error as log_error, info as log_info
from os import path as ospath, environ
from pathlib import Path
from subprocess import run as srun, PIPE
from dotenv import load_dotenv
from datetime import datetime
import pytz

IST = pytz.timezone("Asia/Kolkata")

class ISTFormatter(Formatter):
    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created, IST)
        return dt.strftime(datefmt or "%d-%b-%y %I:%M:%S %p")

log_file = "log.txt"
if ospath.exists(log_file):
    with open(log_file, "w") as f:
        f.truncate(0)

file_handler = FileHandler(log_file)
stream_handler = StreamHandler()

formatter = ISTFormatter("[%(asctime)s] [%(levelname)s] - %(message)s", "%d-%b-%y %I:%M:%S %p")
file_handler.setFormatter(formatter)
stream_handler.setFormatter(formatter)

basicConfig(handlers=[file_handler, stream_handler], level=INFO)

load_dotenv("config.env")

UPSTREAM_REPO = environ.get("UPSTREAM_REPO", "https://github.com/allenspark10/streamio.git").strip() or None
UPSTREAM_BRANCH = environ.get("UPSTREAM_BRANCH", "master").strip() or "master"
GITHUB_TOKEN = environ.get("GITHUB_TOKEN", "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").strip() or None

if UPSTREAM_REPO:
    if Path(".git").exists():
        srun(["rm", "-rf", ".git"])

    # Extract clean repo URL (remove any existing token)
    clean_repo = UPSTREAM_REPO
    if "@github.com" in UPSTREAM_REPO:
        # If URL already has token, extract clean URL
        clean_repo = "https://github.com/" + UPSTREAM_REPO.split("@github.com/")[1]
    
    # Build authenticated URL only for fetch operation
    if GITHUB_TOKEN:
        auth_repo = clean_repo.replace("https://", f"https://x-access-token:{GITHUB_TOKEN}@")
    else:
        auth_repo = clean_repo
    
    update_cmd = (
        f"git init -q && "
        f"git config --global user.email 'doc.adhikari@gmail.com' && "
        f"git config --global user.name 'weebzone' && "
        f"git add . && git commit -sm 'update' -q && "
        f"git remote add origin {clean_repo} && "  # Store clean URL in git config
        f"git fetch {auth_repo} {UPSTREAM_BRANCH} -q && "  # Use token only for fetch
        f"git reset --hard FETCH_HEAD -q"
    )

    update = srun(update_cmd, shell=True)
    
    # Display clean repo info in logs
    repo = clean_repo.strip("/").split("/")
    if len(repo) >= 2:
        repo_url = f"https://github.com/{repo[-2]}/{repo[-1].replace('.git', '')}"
    else:
        repo_url = clean_repo
    
    log_info(f"UPSTREAM_REPO: {repo_url} | UPSTREAM_BRANCH: {UPSTREAM_BRANCH}")

    if update.returncode == 0:
        log_info("Successfully updated with latest commits!!")
        
        # Get commit ID and commit message
        commit_hash = srun(["git", "rev-parse", "--short", "HEAD"], stdout=PIPE, text=True)
        commit_msg = srun(["git", "log", "-1", "--pretty=%B"], stdout=PIPE, text=True)
        
        if commit_hash.returncode == 0 and commit_msg.returncode == 0:
            commit_id = commit_hash.stdout.strip()
            commit_message = commit_msg.stdout.strip().split('\n')[0]  # First line only
            log_info(f"📌 Commit ID: {commit_id}")
            log_info(f"💬 Commit Message: {commit_message}")
        else:
            log_error("Could not retrieve commit information")
    else:
        log_error("❌ Update failed! Retry or ask for support.")
