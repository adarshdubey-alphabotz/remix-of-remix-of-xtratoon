"""
Quick script to check MongoDB storage usage
"""
import asyncio
from Backend import db
from Backend.logger import LOGGER

async def check_db_stats():
    try:
        await db.connect()
        
        print("\n" + "="*60)
        print("DATABASE STORAGE REPORT")
        print("="*60)
        
        total_movies = 0
        total_tv = 0
        total_files = 0
        
        # Check all storage databases
        total_storage_dbs = len(db.dbs) - 1
        
        for db_index in range(1, total_storage_dbs + 1):
            db_key = f"storage_{db_index}"
            
            # Count movies
            movie_count = await db.dbs[db_key]["movie"].count_documents({})
            
            # Count TV shows
            tv_count = await db.dbs[db_key]["tv"].count_documents({})
            
            # Count total files in movies
            movie_pipeline = [
                {"$unwind": "$telegram"},
                {"$count": "total"}
            ]
            movie_files = await db.dbs[db_key]["movie"].aggregate(movie_pipeline).to_list(None)
            movie_file_count = movie_files[0]["total"] if movie_files else 0
            
            # Count total files in TV shows
            tv_pipeline = [
                {"$unwind": "$seasons"},
                {"$unwind": "$seasons.episodes"},
                {"$unwind": "$seasons.episodes.telegram"},
                {"$count": "total"}
            ]
            tv_files = await db.dbs[db_key]["tv"].aggregate(tv_pipeline).to_list(None)
            tv_file_count = tv_files[0]["total"] if tv_files else 0
            
            files_in_db = movie_file_count + tv_file_count
            
            print(f"\n{db_key.upper()}:")
            print(f"  Movies: {movie_count}")
            print(f"  TV Shows: {tv_count}")
            print(f"  Total Files: {files_in_db}")
            
            total_movies += movie_count
            total_tv += tv_count
            total_files += files_in_db
        
        print(f"\n" + "-"*60)
        print(f"TOTAL ACROSS ALL DATABASES:")
        print(f"  Movies: {total_movies}")
        print(f"  TV Shows: {total_tv}")
        print(f"  Total Files: {total_files}")
        print("="*60 + "\n")
        
        await db.disconnect()
        
    except Exception as e:
        LOGGER.error(f"Error checking stats: {e}")

if __name__ == "__main__":
    asyncio.run(check_db_stats())
