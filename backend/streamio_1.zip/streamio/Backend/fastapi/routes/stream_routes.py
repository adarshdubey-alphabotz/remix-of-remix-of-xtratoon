import math
import secrets
import mimetypes
import asyncio
from typing import Tuple
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import StreamingResponse

from Backend.helper.encrypt import decode_string
from Backend.helper.token_utils import verify_token_async
from Backend.helper.exceptions import InvalidHash
from Backend.helper.custom_dl import ByteStreamer
from Backend.pyrofork.bot import StreamBot, work_loads, multi_clients
from Backend import db

router = APIRouter(tags=["Streaming"])
class_cache = {}

# No concurrency limit - 8GB RAM handles unlimited connections
# Chunk size optimized for minimal API calls and flood ban prevention


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to ensure it can be encoded in latin-1 for HTTP headers.
    Replaces common Unicode characters with ASCII equivalents.
    """
    # Common Unicode character replacements
    replacements = {
        '\u2019': "'",  # Right single quotation mark → apostrophe
        '\u2018': "'",  # Left single quotation mark → apostrophe
        '\u201c': '"',  # Left double quotation mark → quote
        '\u201d': '"',  # Right double quotation mark → quote
        '\u2013': '-',  # En dash → hyphen
        '\u2014': '-',  # Em dash → hyphen
        '\u2026': '...',  # Horizontal ellipsis → three dots
        '\u00a0': ' ',  # Non-breaking space → space
    }
    
    for unicode_char, ascii_char in replacements.items():
        filename = filename.replace(unicode_char, ascii_char)
    
    # Remove any remaining characters that can't be encoded in latin-1
    try:
        filename.encode('latin-1')
    except UnicodeEncodeError:
        # If still has non-latin-1 chars, encode and decode to remove them
        filename = filename.encode('ascii', 'ignore').decode('ascii')
    
    return filename


def parse_range_header(range_header: str, file_size: int) -> Tuple[int, int]:
    if not range_header:
        return 0, file_size - 1
    try:
        range_value = range_header.replace("bytes=", "")
        from_str, until_str = range_value.split("-")
        from_bytes = int(from_str)
        until_bytes = int(until_str) if until_str else file_size - 1
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid Range header: {e}")

    if (until_bytes > file_size - 1) or (from_bytes < 0) or (until_bytes < from_bytes):
        raise HTTPException(
            status_code=416,
            detail="Requested Range Not Satisfiable",
            headers={"Content-Range": f"bytes */{file_size}"},
        )

    return from_bytes, until_bytes


@router.get("/dl/{id}/{name}")
@router.head("/dl/{id}/{name}")
async def stream_handler(request: Request, id: str, name: str):
    from Backend.logger import LOGGER
    
    # No concurrency limit with 8GB RAM
    try:
        LOGGER.info(f"Download request received - ID: {id}, Name: {name}")
        
        # Verify time-based token (64-char tokens are new format)
        if len(id) == 64:
            is_valid, file_id = await verify_token_async(id, db)
            if not is_valid:
                LOGGER.warning(f"Token expired or invalid: {id[:20]}...")
                raise HTTPException(status_code=403, detail="Link expired or invalid. Please get a new link.")
            LOGGER.info(f"Token verified, extracted file_id: {file_id}")
        else:
            # Legacy format - use id directly
            file_id = id
        
        # Decode the string
        try:
            decoded_data = await decode_string(file_id)
            LOGGER.info(f"Decoded data: {decoded_data}")
        except Exception as e:
            LOGGER.error(f"Failed to decode ID '{file_id}': {e}", exc_info=True)
            raise HTTPException(status_code=400, detail=f"Invalid or corrupted download link: {str(e)}")
        
        if not decoded_data.get("msg_id"):
            LOGGER.error(f"Missing msg_id in decoded data: {decoded_data}")
            raise HTTPException(status_code=400, detail="Missing message ID in link")
        
        # Get message from Telegram
        chat_id = f"-100{decoded_data['chat_id']}"
        try:
            LOGGER.info(f"Fetching message {decoded_data['msg_id']} from chat {chat_id}")
            message = await StreamBot.get_messages(int(chat_id), int(decoded_data["msg_id"]))
            
            if not message:
                LOGGER.error(f"Message {decoded_data['msg_id']} not found in chat {chat_id}")
                raise HTTPException(status_code=404, detail="File not found or deleted")
                
        except Exception as e:
            LOGGER.error(f"Failed to fetch message {decoded_data['msg_id']} from chat {chat_id}: {e}", exc_info=True)
            raise HTTPException(status_code=404, detail=f"Could not retrieve file: {str(e)}")
        
        # Get file from message
        file = message.video or message.document
        if not file:
            LOGGER.error(f"Message {decoded_data['msg_id']} has no video or document. Message type: {type(message)}")
            raise HTTPException(status_code=404, detail="File not found in message")
        
        file_hash = file.file_unique_id[:6]
        LOGGER.info(f"File found - Name: {file.file_name}, Size: {file.file_size}, Hash: {file_hash}")
        
        return await media_streamer(
            request,
            chat_id=int(chat_id),
            id=int(decoded_data["msg_id"]),
            secure_hash=file_hash,
            encoded_id=file_id  # Pass original file_id for DB lookup
        )
        
    except HTTPException:
        raise
    except Exception as e:
        LOGGER.error(f"Unexpected error in stream_handler: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


async def media_streamer(
    request: Request,
    chat_id: int,
    id: int,
    secure_hash: str,
    encoded_id: str = None,
) -> StreamingResponse:
    from Backend.logger import LOGGER
    
    try:
        range_header = request.headers.get("Range", "")
        LOGGER.info(f"Streaming file - Chat: {chat_id}, Message: {id}, Range: {range_header or 'Full'}")
        
        index = min(work_loads, key=work_loads.get)
        faster_client = multi_clients[index]

        tg_connect = class_cache.get(faster_client)
        if not tg_connect:
            tg_connect = ByteStreamer(faster_client)
            class_cache[faster_client] = tg_connect

        try:
            file_id = await tg_connect.get_file_properties(chat_id=chat_id, message_id=id)
        except Exception as e:
            LOGGER.error(f"Failed to get file properties for message {id} in chat {chat_id}: {e}", exc_info=True)
            raise HTTPException(status_code=404, detail=f"Could not access file: {str(e)}")
        
        if file_id.unique_id[:6] != secure_hash:
            LOGGER.error(f"Hash mismatch - Expected: {secure_hash}, Got: {file_id.unique_id[:6]}")
            raise InvalidHash

        file_size = file_id.file_size
        from_bytes, until_bytes = parse_range_header(range_header, file_size)

        chunk_size = 1024 * 1024
        offset = from_bytes - (from_bytes % chunk_size)
        first_part_cut = from_bytes - offset
        last_part_cut = (until_bytes % chunk_size) + 1
        req_length = until_bytes - from_bytes + 1
        part_count = math.ceil(until_bytes / chunk_size) - math.floor(offset / chunk_size)

        body = tg_connect.yield_file(
            file_id, index, offset, first_part_cut, last_part_cut, part_count, chunk_size
        )

        # Try to get original filename from database (full caption name)
        from Backend import db
        db_filename = await db.get_filename_by_id(encoded_id) if encoded_id else None
        
        # Use DB filename if found, otherwise fallback to Telegram's truncated name
        file_name = db_filename or file_id.file_name or f"{secrets.token_hex(2)}.unknown"
        
        mime_type = file_id.mime_type or mimetypes.guess_type(file_name)[0] or "application/octet-stream"
        if not file_id.file_name and "/" in mime_type:
            file_name = f"{secrets.token_hex(2)}.{mime_type.split('/')[1]}"
        
        # Sanitize filename to prevent UnicodeEncodeError in HTTP headers
        safe_filename = sanitize_filename(file_name)

        headers = {
            "Content-Type": mime_type,
            "Content-Length": str(req_length),
            "Content-Disposition": f'attachment; filename="{safe_filename}"',
            "Accept-Ranges": "bytes",
            "Cache-Control": "public, max-age=3600, immutable",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
        }
        
        if range_header:
            headers["Content-Range"] = f"bytes {from_bytes}-{until_bytes}/{file_size}"
            status_code = 206
        else:
            status_code = 200
        
        LOGGER.info(f"Streaming setup complete - File: {file_name}, Size: {file_size}, Status: {status_code}")
        
        # Log download for bandwidth tracking (only on full file or first range request)
        if not range_header or from_bytes == 0:
            try:
                # Try to detect quality from filename
                quality = "other"
                name_upper = file_name.upper()
                for q in ["1080P", "720P", "480P", "WEB-DL", "HDRIP"]:
                    if q in name_upper:
                        quality = q.replace("P", "p") if "P" in q else q
                        break
                
                # Log download size directly (bytes)
                await db.log_download(quality, file_size)
            except Exception as e:
                LOGGER.warning(f"Failed to log download bandwidth: {e}")
        
        return StreamingResponse(
            status_code=status_code,
            content=body,
            headers=headers,
            media_type=mime_type,
        )
    except HTTPException:
        raise
    except InvalidHash:
        LOGGER.error(f"Invalid hash for message {id} in chat {chat_id}")
        raise HTTPException(status_code=403, detail="Invalid file access token")
    except Exception as e:
        LOGGER.error(f"Error in media_streamer for message {id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Streaming error: {str(e)}")