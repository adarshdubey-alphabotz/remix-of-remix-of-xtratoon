"""
Force Subscribe Plugin - Commands to manage force subscribe channels.

Admin Commands:
- /fsub <channel_id> - Add a channel to force subscribe list
- /rsub <channel_id> - Remove a channel from force subscribe list  
- /listsub - List all force subscribe channels
- /checkreq - Check pending join requests
- /users <channel_id> - Check users for a specific channel
"""

from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import ChatAdminRequired, UserNotParticipant, ChannelInvalid

from Backend import db
from Backend.helper.custom_filter import CustomFilters
from Backend.logger import LOGGER


@Client.on_message(filters.command("fsub") & filters.private & CustomFilters.owner)
async def add_fsub_channel(client: Client, message: Message):
    """Add a force subscribe channel."""
    if len(message.command) < 2:
        await message.reply_text(
            "❌ **Usage:** `/fsub <channel_id>`\n\n"
            "Example: `/fsub -1001234567890`\n\n"
            "💡 You can get channel ID by forwarding a message from the channel to @userinfobot"
        )
        return
    
    try:
        channel_id = int(message.command[1])
    except ValueError:
        await message.reply_text("❌ Invalid channel ID. Must be a number.")
        return
    
    status_msg = await message.reply_text("⏳ Verifying channel...")
    
    try:
        # Get channel info
        chat = await client.get_chat(channel_id)
        
        # Try to get invite link
        try:
            invite_link = chat.invite_link
            if not invite_link:
                invite_link = (await client.export_chat_invite_link(channel_id))
        except ChatAdminRequired:
            invite_link = f"https://t.me/c/{str(channel_id).replace('-100', '')}"
        
        # Add to database
        success = await db.add_fsub_channel(
            channel_id=channel_id,
            channel_title=chat.title,
            invite_link=invite_link
        )
        
        if success:
            await status_msg.edit_text(
                f"✅ **Channel Added to Force Subscribe!**\n\n"
                f"📢 **Channel:** {chat.title}\n"
                f"🆔 **ID:** `{channel_id}`\n"
                f"🔗 **Link:** {invite_link}"
            )
        else:
            await status_msg.edit_text("❌ Failed to add channel to database.")
            
    except ChannelInvalid:
        await status_msg.edit_text("❌ Invalid channel. Make sure the bot is a member of the channel.")
    except Exception as e:
        LOGGER.error(f"Error adding fsub channel: {e}")
        await status_msg.edit_text(f"❌ Error: {str(e)}")


@Client.on_message(filters.command("rsub") & filters.private & CustomFilters.owner)
async def remove_fsub_channel(client: Client, message: Message):
    """Remove a force subscribe channel."""
    if len(message.command) < 2:
        await message.reply_text(
            "❌ **Usage:** `/rsub <channel_id>`\n\n"
            "Example: `/rsub -1001234567890`\n\n"
            "💡 Use /listsub to see all channels"
        )
        return
    
    try:
        channel_id = int(message.command[1])
    except ValueError:
        await message.reply_text("❌ Invalid channel ID. Must be a number.")
        return
    
    success = await db.remove_fsub_channel(channel_id)
    
    if success:
        await message.reply_text(f"✅ Channel `{channel_id}` removed from force subscribe list.")
    else:
        await message.reply_text(f"❌ Channel `{channel_id}` not found in force subscribe list.")


@Client.on_message(filters.command("listsub") & filters.private & CustomFilters.owner)
async def list_fsub_channels(client: Client, message: Message):
    """List all force subscribe channels."""
    channels = await db.get_fsub_channels()
    
    if not channels:
        await message.reply_text("📭 No force subscribe channels configured.\n\nUse `/fsub <channel_id>` to add one.")
        return
    
    text = "📋 **Force Subscribe Channels:**\n\n"
    
    for i, ch in enumerate(channels, 1):
        text += (
            f"**{i}.** {ch.get('channel_title', 'Unknown')}\n"
            f"   🆔 `{ch.get('channel_id')}`\n"
            f"   🔗 [Join Link]({ch.get('invite_link', '#')})\n\n"
        )
    
    text += f"📊 **Total:** {len(channels)} channels"
    
    await message.reply_text(text, disable_web_page_preview=True)


@Client.on_message(filters.command("checkreq") & filters.private & CustomFilters.owner)
async def check_pending_requests(client: Client, message: Message):
    """Check pending join requests."""
    requests = await db.get_pending_requests()
    
    if not requests:
        await message.reply_text("📭 No pending join requests.")
        return
    
    text = "📋 **Pending Join Requests:**\n\n"
    
    for req in requests[:20]:  # Limit to 20
        username = req.get('username', 'Unknown')
        user_id = req.get('user_id')
        channel_id = req.get('channel_id')
        
        text += f"• User: @{username} (`{user_id}`)\n  Channel: `{channel_id}`\n\n"
    
    if len(requests) > 20:
        text += f"_...and {len(requests) - 20} more_"
    
    await message.reply_text(text)


@Client.on_message(filters.command("users") & filters.private & CustomFilters.owner)
async def check_channel_users(client: Client, message: Message):
    """Check users for a specific channel."""
    if len(message.command) < 2:
        await message.reply_text("❌ **Usage:** `/users <channel_id>`")
        return
    
    try:
        channel_id = int(message.command[1])
    except ValueError:
        await message.reply_text("❌ Invalid channel ID.")
        return
    
    users = await db.get_channel_users(channel_id)
    
    pending = users.get('pending', [])
    approved = users.get('approved', [])
    
    text = f"📊 **Channel Users for `{channel_id}`:**\n\n"
    text += f"✅ **Approved:** {len(approved)}\n"
    text += f"⏳ **Pending:** {len(pending)}\n\n"
    
    if pending:
        text += "**Pending Requests:**\n"
        for req in pending[:10]:
            text += f"• @{req.get('username', 'Unknown')} (`{req.get('user_id')}`)\n"
        if len(pending) > 10:
            text += f"_...and {len(pending) - 10} more_\n"
    
    await message.reply_text(text)


@Client.on_message(filters.command("req") & filters.private)
async def request_join(client: Client, message: Message):
    """User requests to join channels via admin approval."""
    channels = await db.get_fsub_channels()
    
    if not channels:
        await message.reply_text("✅ No channels require subscription.")
        return
    
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check which channels user hasn't joined
    not_joined = []
    for channel in channels:
        try:
            member = await client.get_chat_member(channel["channel_id"], user_id)
            if member.status.value not in ["member", "administrator", "creator"]:
                not_joined.append(channel)
        except UserNotParticipant:
            not_joined.append(channel)
        except Exception:
            not_joined.append(channel)
    
    if not not_joined:
        await message.reply_text("✅ You're already a member of all required channels!")
        return
    
    # Build buttons for channels with request option
    buttons = []
    for ch in not_joined:
        buttons.append([
            InlineKeyboardButton(f"📢 {ch['channel_title']}", url=ch.get('invite_link', '#')),
            InlineKeyboardButton("📝 Request", callback_data=f"reqjoin_{ch['channel_id']}")
        ])
    
    await message.reply_text(
        "📋 **Join Required Channels**\n\n"
        "You can either join directly or request admin approval:\n",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


@Client.on_callback_query(filters.regex(r"^reqjoin_(-?\d+)$"))
async def handle_request_join(client, query):
    """Handle join request callback."""
    user_id = query.from_user.id
    username = query.from_user.username or query.from_user.first_name
    channel_id = int(query.data.split("_")[1])
    
    # Add request to database
    success = await db.add_join_request(user_id, channel_id, username)
    
    if success:
        await query.answer("✅ Request sent! Admin will review it.", show_alert=True)
        
        # Notify admin (owner)
        from Backend.config import Telegram
        try:
            await client.send_message(
                Telegram.OWNER_ID,
                f"📝 **New Join Request**\n\n"
                f"User: @{username} (`{user_id}`)\n"
                f"Channel: `{channel_id}`\n\n"
                f"Use /checkreq to see all pending requests.",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Approve", callback_data=f"approvereq_{user_id}_{channel_id}")]
                ])
            )
        except Exception as e:
            LOGGER.error(f"Failed to notify admin: {e}")
    else:
        await query.answer("❌ Failed to send request.", show_alert=True)


@Client.on_callback_query(filters.regex(r"^approvereq_(\d+)_(-?\d+)$") & CustomFilters.owner)
async def handle_approve_request(client, query):
    """Handle approve request callback."""
    parts = query.data.split("_")
    user_id = int(parts[1])
    channel_id = int(parts[2])
    
    success = await db.approve_join_request(user_id, channel_id)
    
    if success:
        await query.answer("✅ Request approved!", show_alert=True)
        await query.message.edit_text(
            query.message.text + "\n\n✅ **APPROVED**"
        )
        
        # Notify user
        try:
            await client.send_message(
                user_id,
                f"🎉 **Your join request has been approved!**\n\n"
                f"You can now access files from the bot."
            )
        except Exception as e:
            LOGGER.error(f"Failed to notify user: {e}")
    else:
        await query.answer("❌ Failed to approve request.", show_alert=True)
