"""
/fixsub command - Automatically calculate and update dub/sub counts for all TV shows
"""

import time
import asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from Backend import db
from Backend.helper.custom_filter import CustomFilters
from Backend.logger import LOGGER

CANCEL_REQUESTED = False


def progress_bar(done, total, length=20):
    """Generate a text-based progress bar"""
    filled = int(length * (done / total)) if total else length
    return f"[{'█' * filled}{'░' * (length - filled)}] {done}/{total}"


def format_eta(seconds):
    """Format ETA in human-readable format"""
    minutes, sec = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)

    if hours > 0:
        return f"{hours}h {minutes}m {sec}s"
    if minutes > 0:
        return f"{minutes}m {sec}s"
    return f"{sec}s"


@Client.on_callback_query(filters.regex("cancel_fixsub"))
async def cancel_fixsub(_, query):
    """Handle cancel button callback"""
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = True
    await query.message.edit_text("❌ Dub/Sub fixing has been cancelled by the user.")
    await query.answer("Cancelled")


@Client.on_message(filters.command("fixsub") & filters.private & CustomFilters.owner, group=10)
async def fix_sub_handler(_, message):
    """
    Command to automatically calculate and update dub/sub counts for all TV shows.
    Processes all TV shows across all databases and updates their total_dub and total_sub fields.
    """
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = False

    # Count total TV shows
    total_tv_shows = 0
    for i in range(1, db.current_db_index + 1):
        key = f"storage_{i}"
        total_tv_shows += await db.dbs[key]["tv"].count_documents({})

    if total_tv_shows == 0:
        await message.reply_text("ℹ️ No TV shows found in the database.")
        return

    DONE = 0
    UPDATED = 0
    start_time = time.time()

    status = await message.reply_text(
        f"⏳ Initializing dub/sub count calculation...\n"
        f"📺 Total TV shows to process: {total_tv_shows}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixsub")]
        ])
    )

    # Settings
    PROGRESS_INTERVAL = 3.0  # Update progress every 3 seconds
    last_progress_edit = start_time

    async def update_single_show(tv_doc, collection, db_index):
        """Calculate and update dub/sub counts for a single TV show"""
        nonlocal DONE, UPDATED, last_progress_edit

        if CANCEL_REQUESTED:
            return

        try:
            tmdb_id = tv_doc.get("tmdb_id")
            title = tv_doc.get("title", "Unknown")

            # Calculate counts
            # SUB = total episodes, DUB = episodes with dual audio
            from Backend.helper.language_detector import is_dub
            all_episodes = set()
            dual_audio_episodes = set()

            for season in tv_doc.get("seasons", []):
                season_num = season.get("season_number")
                for episode in season.get("episodes", []):
                    episode_num = episode.get("episode_number")
                    telegram_files = episode.get("telegram", [])

                    if telegram_files:
                        episode_key = (season_num, episode_num)
                        # All episodes count towards SUB
                        all_episodes.add(episode_key)
                        
                        # Only dual audio episodes count towards DUB
                        sample_file = telegram_files[0]
                        filename = sample_file.get("name", "")

                        if is_dub(filename):
                            dual_audio_episodes.add(episode_key)

            total_dub = len(dual_audio_episodes)
            total_sub = len(all_episodes)

            # Update in database
            result = await collection.update_one(
                {"tmdb_id": tmdb_id},
                {"$set": {"total_dub": total_dub, "total_sub": total_sub}}
            )

            if result.modified_count > 0:
                UPDATED += 1
                LOGGER.info(f"✅ Updated {title}: DUB={total_dub}, SUB={total_sub}")
            else:
                LOGGER.info(f"⏭️ Skipped {title}: No changes (DUB={total_dub}, SUB={total_sub})")

            DONE += 1

            # Update progress message
            now = time.time()
            if now - last_progress_edit > PROGRESS_INTERVAL:
                last_progress_edit = now
                elapsed = now - start_time
                try:
                    await status.edit_text(
                        f"⏳ Processing TV shows...\n"
                        f"{progress_bar(DONE, total_tv_shows)}\n"
                        f"✅ Updated: {UPDATED}\n"
                        f"⏱ Elapsed: {format_eta(elapsed)}",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixsub")]
                        ])
                    )
                except Exception:
                    pass

        except Exception as e:
            LOGGER.exception(f"Error updating TV show {tv_doc.get('title')}: {e}")
            DONE += 1

    # Process all TV shows
    try:
        tasks = []
        BATCH_SIZE = 10  # Process 10 shows at a time

        for i in range(1, db.current_db_index + 1):
            if CANCEL_REQUESTED:
                break

            db_key = f"storage_{i}"
            collection = db.dbs[db_key]["tv"]
            cursor = collection.find({})

            async for tv_doc in cursor:
                if CANCEL_REQUESTED:
                    break

                tasks.append(update_single_show(tv_doc, collection, i))

                # Process in batches
                if len(tasks) >= BATCH_SIZE:
                    await asyncio.gather(*tasks, return_exceptions=True)
                    tasks = []

        # Process remaining tasks
        if tasks and not CANCEL_REQUESTED:
            await asyncio.gather(*tasks, return_exceptions=True)

    except Exception as e:
        LOGGER.exception(f"Error in fixsub command: {e}")

    if CANCEL_REQUESTED:
        try:
            await status.edit_text("❌ Dub/Sub fixing cancelled by user.")
        except Exception:
            pass
        return

    elapsed = time.time() - start_time
    try:
        await status.edit_text(
            f"🎉 **Dub/Sub Count Update Completed!**\n\n"
            f"{progress_bar(DONE, total_tv_shows)}\n\n"
            f"📊 **Statistics:**\n"
            f"• Total TV shows: {total_tv_shows}\n"
            f"• Updated: {UPDATED}\n"
            f"• Skipped (no changes): {total_tv_shows - UPDATED}\n\n"
            f"⏱ Time Taken: {format_eta(elapsed)}"
        )
    except Exception:
        pass
