import asyncio
from Backend.helper.custom_filter import CustomFilters
from pyrogram import filters, Client, enums
from pyrogram.types import Message
from Backend.logger import LOGGER
from Backend import db
from Backend.helper.anilist import fetch_anilist_data

# Lock to prevent multiple tag updates running at once
TAG_UPDATE_LOCK = asyncio.Lock()

@Client.on_message(filters.command('tags') & filters.private & CustomFilters.owner)
async def update_tags_handler(client: Client, message: Message):
    if TAG_UPDATE_LOCK.locked():
        await message.reply_text("⚠️ A tag update process is already running. Please wait.")
        return

    status_msg = await message.reply_text("🔄 Starting AniList tags update for all media...")
    
    success_count = 0
    fail_count = 0
    skipped_count = 0
    total_processed = 0

    async with TAG_UPDATE_LOCK:
        try:
            # Process Movies
            await status_msg.edit_text("🎬 Fetching tags for Movies...")
            async for movie in db.get_all_media("movie"):
                try:
                    title = movie.get("title")
                    tmdb_id = movie.get("tmdb_id")
                    db_index = movie.get("db_index")
                    
                    if not title or not tmdb_id:
                        skipped_count += 1
                        continue

                    # Fetch data from AniList
                    data = await fetch_anilist_data(title)
                    tags = data.get("tags")

                    if tags:
                        # Update DB
                        if await db.update_media_tags(tmdb_id, tags, "movie", db_index):
                            success_count += 1
                            LOGGER.info(f"✅ Updated tags for Movie: {title}")
                        else:
                            fail_count += 1
                    else:
                        LOGGER.info(f"⚠️ No tags found for Movie: {title}")
                        skipped_count += 1
                    
                    total_processed += 1
                    
                    # Rate limiting to be safe (AniList has 90 req/min)
                    await asyncio.sleep(1.5) 

                    if total_processed % 10 == 0:
                        await status_msg.edit_text(f"🎬 Processing Movies...\n✅ Updated: {success_count}\n⏭️ Skipped: {skipped_count}\n❌ Failed: {fail_count}")

                except Exception as e:
                    LOGGER.error(f"Error processing movie {movie.get('title')}: {e}")
                    fail_count += 1

            # Process TV Shows
            await status_msg.edit_text(f"📺 Fetching tags for TV Shows...\n(Movies Done: {success_count})")
            async for tv in db.get_all_media("tv"):
                try:
                    title = tv.get("title")
                    tmdb_id = tv.get("tmdb_id")
                    db_index = tv.get("db_index")
                    
                    if not title or not tmdb_id:
                        skipped_count += 1
                        continue

                    # Fetch data from AniList
                    data = await fetch_anilist_data(title)
                    tags = data.get("tags")

                    if tags:
                        # Update DB
                        if await db.update_media_tags(tmdb_id, tags, "tv", db_index):
                            success_count += 1
                            LOGGER.info(f"✅ Updated tags for TV: {title}")
                        else:
                            fail_count += 1
                    else:
                        LOGGER.info(f"⚠️ No tags found for TV: {title}")
                        skipped_count += 1
                    
                    total_processed += 1
                    
                    # Rate limiting
                    await asyncio.sleep(1.5)

                    if total_processed % 10 == 0:
                        await status_msg.edit_text(f"📺 Processing TV Shows...\n✅ Updated: {success_count}\n⏭️ Skipped: {skipped_count}\n❌ Failed: {fail_count}")

                except Exception as e:
                    LOGGER.error(f"Error processing TV {tv.get('title')}: {e}")
                    fail_count += 1

            await status_msg.edit_text(
                f"✅ **Tag Update Completed!**\n\n"
                f"📊 Total Processed: {total_processed}\n"
                f"✅ Successful: {success_count}\n"
                f"⏭️ Skipped/No Tags: {skipped_count}\n"
                f"❌ Failed: {fail_count}",
                parse_mode=enums.ParseMode.MARKDOWN
            )

        except Exception as e:
            LOGGER.error(f"Critical error in tag update: {e}")
            await status_msg.edit_text(f"❌ Critical Error: {str(e)}")
