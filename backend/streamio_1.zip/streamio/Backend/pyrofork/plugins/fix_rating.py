
import time
import asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from Backend import db
from Backend.helper.custom_filter import CustomFilters
from Backend.helper.imdb import get_detail, search_title
from Backend.logger import LOGGER

CANCEL_REQUESTED = False


def progress_bar(done, total, length=20):
    filled = int(length * done / total) if total else 0
    return "█" * filled + "░" * (length - filled)


def format_eta(seconds):
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        return f"{int(seconds // 60)}m {int(seconds % 60)}s"
    else:
        return f"{int(seconds // 3600)}h {int((seconds % 3600) // 60)}m"


@Client.on_callback_query(filters.regex(r"^cancel_fixrating$") & CustomFilters.owner)
async def cancel_fixrating(_, query):
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = True
    LOGGER.info("Rating fix cancellation requested by user")
    await query.answer("Cancelling... will stop after current item.", show_alert=True)


@Client.on_message(filters.command("fixrating") & filters.private & CustomFilters.owner)
async def fixrating_handler(_, message):
    """
    Fix ratings for all anime in the database.
    Searches IMDB (Cinemeta) for each title, validates it has Animation genre,
    and updates the rating with the correct IMDB rating.
    """
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = False

    LOGGER.info("Starting /fixrating command - bulk rating fix from IMDB")

    status_msg = await message.reply_text(
        "🔄 **Starting Rating Fix**\n\n"
        "Fetching all entries from database...\n"
        "Will only update ratings for entries with Animation genre in IMDB.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixrating")]
        ])
    )

    start_time = time.time()
    updated_count = 0
    skipped_count = 0
    failed_count = 0
    total_processed = 0
    
    # Rate limit: ~2 req/sec for Cinemeta
    RATE_DELAY = 1.0
    PROGRESS_INTERVAL = 5

    try:
        # ---------- Process TV Shows ----------
        LOGGER.info("Processing TV shows for rating fix...")
        await status_msg.edit_text(
            "🔄 **Fixing Ratings — TV Shows...**\n\nPlease wait...",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixrating")]
            ])
        )

        for db_key in db.dbs.keys():
            if not db_key.startswith("storage_"):
                continue
            if CANCEL_REQUESTED:
                break

            collection = db.dbs[db_key]["tv"]
            cursor = collection.find({})
            tv_docs = await cursor.to_list(length=None)
            LOGGER.info(f"Found {len(tv_docs)} TV shows in {db_key}")

            for i, doc in enumerate(tv_docs):
                if CANCEL_REQUESTED:
                    break

                title = doc.get("title", "")
                imdb_id = doc.get("imdb_id")
                current_rating = doc.get("rating", 0)
                total_processed += 1

                try:
                    # If we already have an IMDB ID, fetch details directly
                    if imdb_id:
                        detail = await get_detail(imdb_id, "tvSeries")
                        if detail:
                            genres = detail.get("genre", []) or []
                            has_animation = any(g.lower() == "animation" for g in genres)

                            if has_animation:
                                new_rating = detail.get("rating", {}).get("star", 0)
                                if new_rating and new_rating != current_rating:
                                    await collection.update_one(
                                        {"_id": doc["_id"]},
                                        {"$set": {"rating": new_rating}}
                                    )
                                    updated_count += 1
                                    LOGGER.info(f"✅ TV: {title} — rating {current_rating} → {new_rating}")
                                else:
                                    skipped_count += 1
                            else:
                                skipped_count += 1
                                LOGGER.info(f"⏭️ TV: {title} — not Animation genre in IMDB, skipping")
                        else:
                            failed_count += 1
                            LOGGER.warning(f"❌ TV: {title} — IMDB detail fetch failed for {imdb_id}")
                    else:
                        # No IMDB ID — search by title with animation filter
                        result = await search_title(title, "tvSeries", require_animation=True)
                        if result:
                            found_id = result["id"]
                            detail = await get_detail(found_id, "tvSeries")
                            if detail:
                                new_rating = detail.get("rating", {}).get("star", 0)
                                if new_rating:
                                    await collection.update_one(
                                        {"_id": doc["_id"]},
                                        {"$set": {
                                            "rating": new_rating,
                                            "imdb_id": found_id
                                        }}
                                    )
                                    updated_count += 1
                                    LOGGER.info(f"✅ TV: {title} — rating → {new_rating} (found IMDB: {found_id})")
                                else:
                                    skipped_count += 1
                            else:
                                failed_count += 1
                        else:
                            skipped_count += 1
                            LOGGER.info(f"⏭️ TV: {title} — no Animation match in IMDB search")

                except Exception as e:
                    failed_count += 1
                    LOGGER.exception(f"Error fixing rating for TV: {title}: {e}")

                # Progress update
                if (i + 1) % PROGRESS_INTERVAL == 0:
                    elapsed = time.time() - start_time
                    remaining = len(tv_docs) - i - 1
                    eta = remaining * RATE_DELAY

                    try:
                        await status_msg.edit_text(
                            f"🔄 **Fixing Ratings — TV Shows ({db_key})**\n\n"
                            f"Progress: {i + 1}/{len(tv_docs)}\n"
                            f"{progress_bar(i + 1, len(tv_docs))}\n\n"
                            f"✅ Updated: {updated_count}\n"
                            f"⏭️ Skipped: {skipped_count}\n"
                            f"❌ Failed: {failed_count}\n"
                            f"⏱️ ETA: {format_eta(eta)}",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixrating")]
                            ])
                        )
                    except Exception:
                        pass

                if not CANCEL_REQUESTED:
                    await asyncio.sleep(RATE_DELAY)

        # ---------- Process Movies ----------
        if not CANCEL_REQUESTED:
            LOGGER.info("Processing movies for rating fix...")
            await status_msg.edit_text(
                f"🔄 **Fixing Ratings — Movies...**\n\n"
                f"TV Shows done: ✅ {updated_count} | ⏭️ {skipped_count} | ❌ {failed_count}\n\n"
                "Please wait...",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixrating")]
                ])
            )

            for db_key in db.dbs.keys():
                if not db_key.startswith("storage_"):
                    continue
                if CANCEL_REQUESTED:
                    break

                collection = db.dbs[db_key]["movie"]
                cursor = collection.find({})
                movie_docs = await cursor.to_list(length=None)
                LOGGER.info(f"Found {len(movie_docs)} movies in {db_key}")

                for i, doc in enumerate(movie_docs):
                    if CANCEL_REQUESTED:
                        break

                    title = doc.get("title", "")
                    imdb_id = doc.get("imdb_id")
                    current_rating = doc.get("rating", 0)
                    total_processed += 1

                    try:
                        if imdb_id:
                            detail = await get_detail(imdb_id, "movie")
                            if detail:
                                genres = detail.get("genre", []) or []
                                has_animation = any(g.lower() == "animation" for g in genres)

                                if has_animation:
                                    new_rating = detail.get("rating", {}).get("star", 0)
                                    if new_rating and new_rating != current_rating:
                                        await collection.update_one(
                                            {"_id": doc["_id"]},
                                            {"$set": {"rating": new_rating}}
                                        )
                                        updated_count += 1
                                        LOGGER.info(f"✅ Movie: {title} — rating {current_rating} → {new_rating}")
                                    else:
                                        skipped_count += 1
                                else:
                                    skipped_count += 1
                                    LOGGER.info(f"⏭️ Movie: {title} — not Animation genre, skipping")
                            else:
                                failed_count += 1
                        else:
                            result = await search_title(title, "movie", require_animation=True)
                            if result:
                                found_id = result["id"]
                                detail = await get_detail(found_id, "movie")
                                if detail:
                                    new_rating = detail.get("rating", {}).get("star", 0)
                                    if new_rating:
                                        await collection.update_one(
                                            {"_id": doc["_id"]},
                                            {"$set": {
                                                "rating": new_rating,
                                                "imdb_id": found_id
                                            }}
                                        )
                                        updated_count += 1
                                        LOGGER.info(f"✅ Movie: {title} — rating → {new_rating} (IMDB: {found_id})")
                                    else:
                                        skipped_count += 1
                                else:
                                    failed_count += 1
                            else:
                                skipped_count += 1

                    except Exception as e:
                        failed_count += 1
                        LOGGER.exception(f"Error fixing rating for Movie: {title}: {e}")

                    if (i + 1) % PROGRESS_INTERVAL == 0:
                        elapsed = time.time() - start_time
                        remaining = len(movie_docs) - i - 1
                        eta = remaining * RATE_DELAY

                        try:
                            await status_msg.edit_text(
                                f"🔄 **Fixing Ratings — Movies ({db_key})**\n\n"
                                f"Progress: {i + 1}/{len(movie_docs)}\n"
                                f"{progress_bar(i + 1, len(movie_docs))}\n\n"
                                f"✅ Updated: {updated_count}\n"
                                f"⏭️ Skipped: {skipped_count}\n"
                                f"❌ Failed: {failed_count}\n"
                                f"⏱️ ETA: {format_eta(eta)}",
                                reply_markup=InlineKeyboardMarkup([
                                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixrating")]
                                ])
                            )
                        except Exception:
                            pass

                    if not CANCEL_REQUESTED:
                        await asyncio.sleep(RATE_DELAY)

        # ---------- Final Summary ----------
        elapsed = time.time() - start_time
        status = "✅ **Rating Fix Complete!**" if not CANCEL_REQUESTED else "⚠️ **Rating Fix Cancelled**"

        LOGGER.info(f"Rating fix finished - Updated: {updated_count}, Skipped: {skipped_count}, Failed: {failed_count}, Time: {format_eta(elapsed)}")

        await status_msg.edit_text(
            f"{status}\n\n"
            f"📊 **Summary:**\n"
            f"• Total processed: {total_processed}\n"
            f"• Updated: {updated_count}\n"
            f"• Skipped: {skipped_count}\n"
            f"• Failed: {failed_count}\n"
            f"• Time: {format_eta(elapsed)}"
        )

    except Exception as e:
        LOGGER.error(f"Error in fixrating: {e}", exc_info=True)
        await status_msg.edit_text(
            f"❌ **Error during rating fix:**\n\n`{str(e)}`\n\n"
            f"Updated so far: {updated_count}"
        )
