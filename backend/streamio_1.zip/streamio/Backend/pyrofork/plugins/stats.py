from pyrogram import Client, filters
from pyrogram.types import Message
from Backend import db
from Backend.config import Telegram
from Backend.logger import LOGGER


@Client.on_message(filters.command(["str", "calculate"]) & filters.user(Telegram.OWNER_ID))
async def calculate_storage_command(client: Client, message: Message):
    """Calculate storage stats by quality (runs full calculation)."""
    
    status_msg = await message.reply_text("📊 **Calculating storage stats...**\n\nThis may take a moment for large databases.")
    
    try:
        # Calculate storage stats
        stats = await db.calculate_quality_storage()
        
        # Format response
        text = "📊 **Storage Statistics by Quality**\n\n"
        
        # Quality breakdown
        text += "**📁 Storage by Quality:**\n"
        for quality in ["480p", "720p", "1080p", "WEB-DL", "HDRip", "other"]:
            size = stats.get("quality_sizes_readable", {}).get(quality, "0 B")
            count = stats.get("quality_counts", {}).get(quality, 0)
            if count > 0:
                text += f"  • **{quality}:** {size} ({count} files)\n"
        
        text += f"\n**📦 Total Storage:** {stats.get('total_size_readable', '0 B')}"
        text += f"\n**📄 Total Files:** {stats.get('total_files', 0):,}"
        text += f"\n\n✅ *Calculation complete!*"
        
        await status_msg.edit_text(text)
        LOGGER.info(f"Storage stats calculated by {message.from_user.id}")
        
    except Exception as e:
        LOGGER.error(f"Error calculating storage stats: {e}")
        await status_msg.edit_text(f"❌ **Error calculating stats:**\n`{str(e)}`")


@Client.on_message(filters.command(["stats", "storagestats"]) & filters.user(Telegram.OWNER_ID))
async def storage_stats_command(client: Client, message: Message):
    """Display cached storage stats (no calculation)."""
    
    try:
        # Get cached stats
        stats = await db.get_storage_stats()
        
        if not stats:
            await message.reply_text("📊 **No stats cached yet.**\n\nUse `/str` to calculate storage stats first.")
            return
        
        # Format response
        text = "📊 **Storage Statistics by Quality**\n\n"
        
        # Quality breakdown
        text += "**📁 Storage by Quality:**\n"
        for quality in ["480p", "720p", "1080p", "WEB-DL", "HDRip", "other"]:
            size = stats.get("quality_sizes_readable", {}).get(quality, "0 B")
            count = stats.get("quality_counts", {}).get(quality, 0)
            if count > 0:
                text += f"  • **{quality}:** {size} ({count} files)\n"
        
        text += f"\n**📦 Total Storage:** {stats.get('total_size_readable', '0 B')}"
        text += f"\n**📄 Total Files:** {stats.get('total_files', 0):,}"
        
        # Show last calculated time
        last_calc = stats.get("last_calculated")
        if last_calc:
            text += f"\n\n⏱ *Last calculated: {last_calc.strftime('%Y-%m-%d %H:%M')} UTC*"
        
        # Get bandwidth stats
        bandwidth = await db.get_current_month_bandwidth()
        if bandwidth:
            text += "\n\n**📡 This Month's Bandwidth:**\n"
            text += f"  **Total:** {bandwidth.get('total_bandwidth_readable', '0 B')}\n"
            text += f"  **Downloads:** {bandwidth.get('download_count', 0):,}\n"
            
            # Quality breakdown
            if bandwidth.get("quality_bandwidth_readable"):
                text += "  **By Quality:**\n"
                for quality, bw in bandwidth["quality_bandwidth_readable"].items():
                    if bw != "0.00 B":
                        text += f"    • {quality}: {bw}\n"
        
        await message.reply_text(text)
        
    except Exception as e:
        LOGGER.error(f"Error getting storage stats: {e}")
        await message.reply_text(f"❌ **Error:**\n`{str(e)}`")


@Client.on_message(filters.command(["bandwidth", "bw"]) & filters.user(Telegram.OWNER_ID))
async def bandwidth_stats_command(client: Client, message: Message):
    """Display bandwidth usage stats."""
    
    try:
        # Get monthly bandwidth stats
        stats = await db.get_bandwidth_stats(months=6)
        
        if not stats:
            await message.reply_text("📡 **No bandwidth data yet.**\n\nBandwidth tracking will start when users download files.")
            return
        
        text = "📡 **Bandwidth Usage Stats**\n\n"
        
        for stat in stats:
            month = stat.get("year_month", stat.get("_id", "Unknown"))
            total = stat.get("total_bandwidth_readable", "0 B")
            downloads = stat.get("download_count", 0)
            text += f"**{month}:** {total} ({downloads:,} downloads)\n"
            
            # Quality breakdown
            if stat.get("quality_bandwidth_readable"):
                for quality, bw in stat["quality_bandwidth_readable"].items():
                    if bw != "0.00 B":
                        text += f"  • {quality}: {bw}\n"
            text += "\n"
        
        await message.reply_text(text)
        
    except Exception as e:
        LOGGER.error(f"Error getting bandwidth stats: {e}")
        await message.reply_text(f"❌ **Error:**\n`{str(e)}`")
