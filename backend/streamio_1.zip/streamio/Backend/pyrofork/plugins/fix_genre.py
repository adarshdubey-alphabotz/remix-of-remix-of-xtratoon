import time
import asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from Backend import db
from Backend.helper.custom_filter import CustomFilters
from Backend.helper.anilist import fetch_anilist_data
from Backend.logger import LOGGER

CANCEL_REQUESTED = False

# Rate limiting: AniList allows ~90 requests per minute
# Using 1.5s delay = ~40 requests per minute (safe margin)
ANILIST_DELAY = 1.5


def progress_bar(done, total, length=20):
    filled = int(length * done / total) if total else 0
    return "█" * filled + "░" * (length - filled)


def format_eta(seconds):
    if seconds < 60:
        return f"{int(seconds)}s"
    elif seconds < 3600:
        return f"{int(seconds // 60)}m {int(seconds % 60)}s"
    else:
        return f"{int(seconds // 3600)}h {int((seconds % 3600) // 60)}m"


@Client.on_callback_query(filters.regex(r"^cancel_fixgenre$") & CustomFilters.owner)
async def cancel_fixgenre(_, query):
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = True
    LOGGER.info("Genre fix cancellation requested by user")
    await query.answer("Cancelling... will stop after current item.", show_alert=True)


@Client.on_message(filters.command("fixgenre") & filters.private & CustomFilters.owner)
async def fixgenre_handler(_, message):
    """Bulk update anime genres from AniList for all entries in database."""
    global CANCEL_REQUESTED
    CANCEL_REQUESTED = False
    
    LOGGER.info("Starting /fixgenre command - bulk genre update from AniList")
    
    status_msg = await message.reply_text(
        "🔄 **Starting Genre Fix**\n\n"
        "Fetching all entries from database...\n"
        f"⏱️ Using {ANILIST_DELAY}s delay to avoid rate limits",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixgenre")]
        ])
    )
    
    start_time = time.time()
    updated_count = 0
    skipped_count = 0
    failed_count = 0
    total_processed = 0
    
    try:
        # Process TV Shows
        LOGGER.info("Processing TV shows...")
        await status_msg.edit_text(
            "🔄 **Processing TV Shows...**\n\n"
            "Please wait...",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixgenre")]
            ])
        )
        
        # Get all TV shows from all databases
        for db_idx, db_key in enumerate(db.dbs.keys()):
            if not db_key.startswith("storage_"):
                continue
            if CANCEL_REQUESTED:
                break
            
            LOGGER.info(f"Processing TV shows from {db_key}")
            collection = db.dbs[db_key]["tv"]
            cursor = collection.find({})
            tv_docs = await cursor.to_list(length=None)
            LOGGER.info(f"Found {len(tv_docs)} TV shows in {db_key}")
            
            for i, doc in enumerate(tv_docs):
                if CANCEL_REQUESTED:
                    LOGGER.info("Cancellation requested, stopping...")
                    break
                
                title = doc.get("title", "")
                current_genres = doc.get("genres", [])
                total_processed += 1
                
                LOGGER.info(f"[{total_processed}] Fetching genres for TV: {title}")
                
                # Try to fetch AniList genres
                anilist_data = await fetch_anilist_data(title)
                anilist_genres = anilist_data.get("genres", [])
                
                # Check cancel again after API call
                if CANCEL_REQUESTED:
                    LOGGER.info("Cancellation requested after API call, stopping...")
                    break
                
                if anilist_genres:
                    # Update the document with new genres
                    genre_str = ",".join(anilist_genres)
                    await collection.update_one(
                        {"_id": doc["_id"]},
                        {"$set": {"genres": anilist_genres}}
                    )
                    updated_count += 1
                    LOGGER.info(f"✅ Updated TV: {title} -> {genre_str}")
                else:
                    skipped_count += 1
                    LOGGER.info(f"⏭️ Skipped TV: {title} (no AniList match)")
                
                # Update progress every 5 items
                if (i + 1) % 5 == 0:
                    elapsed = time.time() - start_time
                    rate = total_processed / elapsed if elapsed > 0 else 0
                    remaining = len(tv_docs) - i - 1
                    eta = remaining * ANILIST_DELAY
                    
                    await status_msg.edit_text(
                        f"🔄 **Processing TV Shows ({db_key})**\n\n"
                        f"Progress: {i + 1}/{len(tv_docs)}\n"
                        f"{progress_bar(i + 1, len(tv_docs))}\n\n"
                        f"✅ Updated: {updated_count}\n"
                        f"⏭️ Skipped: {skipped_count}\n"
                        f"⏱️ ETA: {format_eta(eta)}",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixgenre")]
                        ])
                    )
                
                # Rate limiting - check cancel during sleep
                if not CANCEL_REQUESTED:
                    await asyncio.sleep(ANILIST_DELAY)
        
        # Process Movies
        if not CANCEL_REQUESTED:
            LOGGER.info("Processing movies...")
            await status_msg.edit_text(
                "🔄 **Processing Movies...**\n\n"
                f"TV Shows done: ✅ {updated_count} | ⏭️ {skipped_count}\n\n"
                "Please wait...",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixgenre")]
                ])
            )
            
            for db_idx, db_key in enumerate(db.dbs.keys()):
                if not db_key.startswith("storage_"):
                    continue
                if CANCEL_REQUESTED:
                    break
                
                LOGGER.info(f"Processing movies from {db_key}")
                collection = db.dbs[db_key]["movie"]
                cursor = collection.find({})
                movie_docs = await cursor.to_list(length=None)
                LOGGER.info(f"Found {len(movie_docs)} movies in {db_key}")
                
                for i, doc in enumerate(movie_docs):
                    if CANCEL_REQUESTED:
                        LOGGER.info("Cancellation requested, stopping...")
                        break
                    
                    title = doc.get("title", "")
                    current_genres = doc.get("genres", [])
                    total_processed += 1
                    
                    LOGGER.info(f"[{total_processed}] Fetching genres for Movie: {title}")
                    
                    # Try to fetch AniList genres
                    anilist_data = await fetch_anilist_data(title)
                    anilist_genres = anilist_data.get("genres", [])
                    
                    # Check cancel again after API call
                    if CANCEL_REQUESTED:
                        LOGGER.info("Cancellation requested after API call, stopping...")
                        break
                    
                    if anilist_genres:
                        genre_str = ",".join(anilist_genres)
                        await collection.update_one(
                            {"_id": doc["_id"]},
                            {"$set": {"genres": anilist_genres}}
                        )
                        updated_count += 1
                        LOGGER.info(f"✅ Updated Movie: {title} -> {genre_str}")
                    else:
                        skipped_count += 1
                        LOGGER.info(f"⏭️ Skipped Movie: {title} (no AniList match)")
                    
                    # Update progress every 5 items
                    if (i + 1) % 5 == 0:
                        elapsed = time.time() - start_time
                        remaining = len(movie_docs) - i - 1
                        eta = remaining * ANILIST_DELAY
                        
                        await status_msg.edit_text(
                            f"🔄 **Processing Movies ({db_key})**\n\n"
                            f"Progress: {i + 1}/{len(movie_docs)}\n"
                            f"{progress_bar(i + 1, len(movie_docs))}\n\n"
                            f"✅ Updated: {updated_count}\n"
                            f"⏭️ Skipped: {skipped_count}",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("❌ Cancel", callback_data="cancel_fixgenre")]
                            ])
                        )
                    
                    # Rate limiting - check cancel during sleep
                    if not CANCEL_REQUESTED:
                        await asyncio.sleep(ANILIST_DELAY)
        
        # Final summary
        elapsed = time.time() - start_time
        status = "✅ **Genre Fix Complete!**" if not CANCEL_REQUESTED else "⚠️ **Genre Fix Cancelled**"
        
        LOGGER.info(f"Genre fix finished - Updated: {updated_count}, Skipped: {skipped_count}, Time: {format_eta(elapsed)}")
        
        await status_msg.edit_text(
            f"{status}\n\n"
            f"📊 **Summary:**\n"
            f"• Total processed: {total_processed}\n"
            f"• Updated: {updated_count}\n"
            f"• Skipped (no AniList match): {skipped_count}\n"
            f"• Failed: {failed_count}\n"
            f"• Time: {format_eta(elapsed)}"
        )
        
    except Exception as e:
        LOGGER.error(f"Error in fixgenre: {e}", exc_info=True)
        await status_msg.edit_text(
            f"❌ **Error during genre fix:**\n\n`{str(e)}`\n\n"
            f"Updated so far: {updated_count}"
        )

