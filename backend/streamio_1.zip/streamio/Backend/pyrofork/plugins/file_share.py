import asyncio
import zlib
import json
from pyrogram import filters, Client
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import FloodWait, ChatForwardsRestricted, MessageIdInvalid, UserNotParticipant

from Backend import db
from Backend.logger import LOGGER
from Backend.helper.token_utils import generate_token, verify_token_async


def decode_string(encoded_data: str) -> dict:
    """Decode base62 + zlib compressed data"""
    BASE62_ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    try:
        # Base62 decode
        num = 0
        for char in encoded_data:
            num = num * 62 + BASE62_ALPHABET.index(char)
        compressed_data = num.to_bytes((num.bit_length() + 7) // 8, 'big') or b'\0'
        
        # Decompress
        json_data = zlib.decompress(compressed_data).decode()
        return json.loads(json_data)
    except Exception as e:
        raise ValueError(f"Invalid encoded data: {str(e)}")


async def check_user_subscribed(client: Client, user_id: int) -> tuple[bool, list]:
    """
    Check if user is subscribed to all fsub channels.
    Returns (is_subscribed, list_of_not_joined_channels)
    """
    fsub_channels = await db.get_fsub_channels()
    
    if not fsub_channels:
        return True, []
    
    not_joined = []
    
    for channel in fsub_channels:
        channel_id = channel.get("channel_id")
        try:
            member = await client.get_chat_member(channel_id, user_id)
            # Check if user is actually a member
            if member.status.value not in ["member", "administrator", "creator"]:
                not_joined.append(channel)
        except UserNotParticipant:
            # User is not in the channel, check if they have an approved request
            user_requests = await db.get_user_requests(user_id)
            approved = any(
                r.get("channel_id") == channel_id and r.get("status") == "approved"
                for r in user_requests
            )
            if not approved:
                not_joined.append(channel)
        except Exception as e:
            LOGGER.warning(f"Error checking membership for {channel_id}: {e}")
            # If we can't check, check for approved request
            user_requests = await db.get_user_requests(user_id)
            approved = any(
                r.get("channel_id") == channel_id and r.get("status") == "approved"
                for r in user_requests
            )
            if not approved:
                not_joined.append(channel)
    
    return len(not_joined) == 0, not_joined


@Client.on_message(filters.command('start') & filters.private, group=5)
async def handle_file_share(client: Client, message: Message):
    """Handle encoded file share links - runs BEFORE admin-only start handler"""
    
    # Check if there's an encoded parameter
    if len(message.command) < 2:
        # No parameter, let other handlers handle it
        return
    
    encoded_id = message.command[1]
    
    # Check if it looks like an encoded ID (not a simple command)
    if len(encoded_id) < 20:
        # Too short to be encoded ID, let other handlers deal with it
        return
    
    # If we reach here, this is likely a file share request
    user_id = message.from_user.id
    
    try:
        # Check force subscribe first
        is_subscribed, not_joined = await check_user_subscribed(client, user_id)
        
        if not is_subscribed:
            # Build buttons for channels user needs to join
            buttons = []
            for ch in not_joined:
                buttons.append([
                    InlineKeyboardButton(
                        f"📢 Join {ch.get('channel_title', 'Channel')}", 
                        url=ch.get('invite_link', '#')
                    )
                ])
            
            # Add "I've Joined" verification button
            buttons.append([
                InlineKeyboardButton("✅ I've Joined", callback_data=f"checkjoin_{encoded_id}")
            ])
            
            # Add request option
            buttons.append([
                InlineKeyboardButton("📝 Request Access", callback_data="reqaccess")
            ])
            
            await message.reply_text(
                "⚠️ **Please Join Required Channels**\n\n"
                "You must join the following channels to access files:\n\n"
                f"📊 Channels remaining: **{len(not_joined)}**\n\n"
                "After joining, click '✅ I've Joined' to verify.",
                reply_markup=InlineKeyboardMarkup(buttons)
            )
            return
        
        # User is subscribed, proceed with file sharing
        # Check if this is a 64-char token (new format with expiry)
        if len(encoded_id) == 64:
            is_valid, file_id = await verify_token_async(encoded_id, db)
            if not is_valid:
                await message.reply_text("❌ Link expired! Please get a new link.")
                return
        else:
            # Legacy format - use directly
            file_id = encoded_id
        
        # Decode the file_id to get chat_id and msg_id
        decoded_data = decode_string(file_id)
        
        if not decoded_data.get("msg_id") or not decoded_data.get("chat_id"):
            await message.reply_text("❌ Invalid share link!")
            return
        
        # Construct the full chat_id (add -100 prefix for channels/supergroups)
        chat_id = int(f"-100{decoded_data['chat_id']}")
        msg_id = int(decoded_data["msg_id"])
        
        # Send processing message
        status_msg = await message.reply_text("⏳ Fetching your file...")
        
        # Wait 3 seconds to avoid rate limits
        await asyncio.sleep(3)
        
        try:
            # Try to get the message first to verify it exists
            original_message = await client.get_messages(chat_id, msg_id)
            
            if not original_message:
                await status_msg.edit_text("❌ File not found!")
                return
            
            # Check if it's a media message
            if not (original_message.video or original_message.document or 
                    original_message.audio or original_message.photo):
                await status_msg.edit_text("❌ No media file found in this message!")
                return
            
            # Prepare caption with added text
            original_caption = original_message.caption or ""
            new_caption = f"{original_caption}\n\nMore anime on animeshrine.xyz"
            
            # Copy the message to user
            await client.copy_message(
                chat_id=message.chat.id,
                from_chat_id=chat_id,
                message_id=msg_id,
                caption=new_caption
            )
            
            await status_msg.edit_text("✅ Here's your file!")
            
        except ChatForwardsRestricted:
            await status_msg.edit_text(
                "❌ Cannot forward this file due to channel restrictions.\n"
                "The source channel has disabled forwarding."
            )
        except MessageIdInvalid:
            await status_msg.edit_text(
                "❌ File not found! The message may have been deleted."
            )
        except FloodWait as e:
            await status_msg.edit_text(
                f"⚠️ Rate limit reached. Please wait {e.value} seconds and try again."
            )
            await asyncio.sleep(e.value)
        except Exception as e:
            await status_msg.edit_text(f"❌ Failed to send file: {str(e)}")
            LOGGER.error(f"Error copying message: {e}")
    
    except ValueError as e:
        await message.reply_text(f"❌ Invalid link format: {str(e)}")
    except Exception as e:
        await message.reply_text(f"❌ Error processing request: {str(e)}")
        LOGGER.error(f"Error in file share handler: {e}")


@Client.on_callback_query(filters.regex(r"^checkjoin_(.+)$"))
async def handle_check_join(client, query):
    """Handle 'I've Joined' verification button."""
    user_id = query.from_user.id
    encoded_id = query.data.split("_", 1)[1]
    
    is_subscribed, not_joined = await check_user_subscribed(client, user_id)
    
    if is_subscribed:
        await query.answer("✅ Verified! Sending your file...", show_alert=True)
        
        # Process the file request
        try:
            # Check if this is a 64-char token (new format with expiry)
            if len(encoded_id) == 64:
                is_valid, file_id = await verify_token_async(encoded_id, db)
                if not is_valid:
                    await query.message.edit_text("❌ Link expired! Please get a new link.")
                    return
            else:
                # Legacy format
                file_id = encoded_id
            
            decoded_data = decode_string(file_id)
            chat_id = int(f"-100{decoded_data['chat_id']}")
            msg_id = int(decoded_data["msg_id"])
            
            original_message = await client.get_messages(chat_id, msg_id)
            
            if original_message and (original_message.video or original_message.document or 
                                      original_message.audio or original_message.photo):
                original_caption = original_message.caption or ""
                new_caption = f"{original_caption}\n\nMore anime on animeshrine.xyz"
                
                await client.copy_message(
                    chat_id=query.message.chat.id,
                    from_chat_id=chat_id,
                    message_id=msg_id,
                    caption=new_caption
                )
                
                await query.message.edit_text("✅ Here's your file!")
            else:
                await query.message.edit_text("❌ File not found!")
        except Exception as e:
            LOGGER.error(f"Error in checkjoin handler: {e}")
            await query.message.edit_text(f"❌ Error: {str(e)}")
    else:
        await query.answer(
            f"❌ You still need to join {len(not_joined)} channel(s)!", 
            show_alert=True
        )


@Client.on_callback_query(filters.regex(r"^reqaccess$"))
async def handle_request_access(client, query):
    """Handle request access button."""
    user_id = query.from_user.id
    username = query.from_user.username or query.from_user.first_name
    
    is_subscribed, not_joined = await check_user_subscribed(client, user_id)
    
    if is_subscribed:
        await query.answer("✅ You already have access!", show_alert=True)
        return
    
    # Add request for each channel user hasn't joined
    for channel in not_joined:
        await db.add_join_request(user_id, channel.get("channel_id"), username)
    
    await query.answer("✅ Request sent to admin!", show_alert=True)
    
    # Notify admin
    from Backend.config import Telegram
    try:
        await client.send_message(
            Telegram.OWNER_ID,
            f"📝 **New Access Request**\n\n"
            f"User: @{username} (`{user_id}`)\n"
            f"Channels: {len(not_joined)}\n\n"
            f"Use /checkreq to review."
        )
    except Exception as e:
        LOGGER.error(f"Failed to notify admin: {e}")

