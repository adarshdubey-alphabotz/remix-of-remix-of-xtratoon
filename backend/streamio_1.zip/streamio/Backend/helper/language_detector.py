"""
Helper module for analyzing audio/subtitle languages in media filenames.
Used to count dubbed and subtitled episodes automatically.
"""

import re
from typing import Dict, Set, Tuple


# Language patterns to detect in filenames (case-insensitive)
# Only the 3 main languages used
LANGUAGE_PATTERNS = {
    'japanese': [
        r'\bjapanese\b',
        r'\bjpn?\b',
    ],
    'english': [
        r'\benglish\b',
        r'\beng\b',
        r'\beng?\b',
    ],
    'hindi': [
        r'\bhindi\b',
        r'\bhin\b',
        r'\bhin?\b',
    ],
}


def detect_languages(filename: str) -> Set[str]:
    """
    Detect all languages present in a filename.
    
    Args:
        filename: The filename to analyze
        
    Returns:
        Set of detected language names (e.g., {'japanese', 'english'})
    """
    filename_lower = filename.lower()
    detected = set()
    
    for language, patterns in LANGUAGE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, filename_lower, re.IGNORECASE):
                detected.add(language)
                break  # Found this language, move to next
    
    return detected


def is_dub(filename: str) -> bool:
    """
    Determine if a file should be counted as DUB based on language detection.
    
    Rules:
    1. If English or Hindi is present → DUB
    2. If Japanese is present WITH other languages → DUB (dual audio)
    3. If ONLY Japanese → SUB
    
    Args:
        filename: The filename to analyze
        
    Returns:
        True if the file should be counted as DUB, False otherwise
    """
    languages = detect_languages(filename)
    
    # If English or Hindi is detected, it's a dub
    if 'english' in languages or 'hindi' in languages:
        return True
    
    # If Japanese is present WITH other languages, it's a dub (dual audio)
    if 'japanese' in languages and len(languages) > 1:
        return True
    
    # Japanese only or no recognized dub language = SUB
    return False


def is_sub(filename: str) -> bool:
    """
    Determine if a file should be counted as SUB based on language detection.
    
    A file is SUB if it has subtitles or if it's not a dub.
    For now, we'll consider any file without Japanese audio as SUB.
    
    Args:
        filename: The filename to analyze
        
    Returns:
        True if the file should be counted as SUB, False otherwise
    """
    # If it's not a dub, it's a sub
    # Or if it has explicit subtitle markers
    return not is_dub(filename)


def analyze_filename(filename: str) -> Dict[str, bool]:
    """
    Comprehensive analysis of a filename for dub/sub classification.
    
    Args:
        filename: The filename to analyze
        
    Returns:
        Dict with 'is_dub' and 'is_sub' boolean flags
    """
    return {
        'is_dub': is_dub(filename),
        'is_sub': is_sub(filename),
        'languages': list(detect_languages(filename))
    }


def count_dub_sub_from_telegram_files(telegram_files: list) -> Tuple[int, int]:
    """
    Count unique dub and sub files from a list of telegram quality files.
    Each file is counted only once, regardless of how many qualities exist.
    
    We group files by their base characteristics (ignoring quality) and count
    unique dub/sub files.
    
    Args:
        telegram_files: List of QualityDetail dicts with 'name' field
        
    Returns:
        Tuple of (dub_count, sub_count)
    """
    if not telegram_files:
        return 0, 0
    
    # Track unique files (by name without quality markers)
    unique_dubs = set()
    unique_subs = set()
    
    for file_info in telegram_files:
        filename = file_info.get('name', '')
        if not filename:
            continue
        
        # Remove quality markers to get base filename
        base_name = re.sub(r'\b(?:480p|720p|1080p|2160p|4k|hd|sd|bluray|webrip|web-dl|hdrip)\b', '', filename, flags=re.IGNORECASE).strip()
        
        if is_dub(filename):
            unique_dubs.add(base_name)
        else:
            unique_subs.add(base_name)
    
    return len(unique_dubs), len(unique_subs)
