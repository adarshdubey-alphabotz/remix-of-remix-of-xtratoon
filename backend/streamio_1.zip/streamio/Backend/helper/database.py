
from asyncio import create_task
from bson import ObjectId
import motor.motor_asyncio
from datetime import datetime
from pydantic import ValidationError
from pymongo import ASCENDING, DESCENDING
from typing import Dict, List, Optional, Tuple, Any

from Backend.logger import LOGGER
from Backend.config import Telegram
import re
from Backend.helper.encrypt import decode_string, encode_string
from Backend.helper.modal import Episode, MovieSchema, QualityDetail, Season, TVShowSchema
from Backend.helper.task_manager import delete_message


def convert_objectid_to_str(document: Dict[str, Any]) -> Dict[str, Any]:
    for key, value in document.items():
        if isinstance(value, ObjectId):
            document[key] = str(value)
        elif isinstance(value, list):
            document[key] = [convert_objectid_to_str(item) if isinstance(item, dict) else item for item in value]
        elif isinstance(value, dict):
            document[key] = convert_objectid_to_str(value)
    return document


class Database:
    def __init__(self, db_name: str = "dbFyvio"):
        self.db_uris = Telegram.DATABASE
        self.db_name = db_name

        if len(self.db_uris) < 2:
            raise ValueError("At least 2 database URIs are required (1 for tracking + 1 for storage).")

        self.clients: Dict[str, motor.motor_asyncio.AsyncIOMotorClient] = {}
        self.dbs: Dict[str, motor.motor_asyncio.AsyncIOMotorDatabase] = {}

        self.current_db_index = 1

    async def connect(self):
        try:
            for index, uri in enumerate(self.db_uris):
                client = motor.motor_asyncio.AsyncIOMotorClient(uri)
                db_key = "tracking" if index == 0 else f"storage_{index}"
                self.clients[db_key] = client
                self.dbs[db_key] = client[self.db_name]
                db_type = "Tracking" if index == 0 else f"Storage {index}"

                masked_uri = re.sub(r"://(.*?):.*?@", r"://\1:*****@", uri)
                masked_uri = masked_uri.split('?')[0]
                
                LOGGER.info(f"{db_type} Database connected successfully: {masked_uri}")

            state = await self.dbs["tracking"]["state"].find_one({"_id": "db_index"})
            if not state:
                await self.dbs["tracking"]["state"].insert_one({"_id": "db_index", "current_index": 1})
                self.current_db_index = 1
            else:
                self.current_db_index = state["current_index"]

            LOGGER.info(f"Active storage DB: storage_{self.current_db_index}")

        except Exception as e:
            LOGGER.error(f"Database connection error: {e}")

    async def disconnect(self):
        for client in self.clients.values():
            client.close()
        LOGGER.info("All database connections closed.")

    async def update_current_db_index(self):
        await self.dbs["tracking"]["state"].update_one(
            {"_id": "db_index"},
            {"$set": {"current_index": self.current_db_index}},
            upsert=True
        )

    async def create_indexes(self):
        """Create indexes for fast filename lookups"""
        try:
            total_storage_dbs = len(self.dbs) - 1
            for db_index in range(1, total_storage_dbs + 1):
                db_key = f"storage_{db_index}"
                
                # Index for movie telegram IDs
                await self.dbs[db_key]["movie"].create_index("telegram.id")
                
                # Index for TV show telegram IDs
                await self.dbs[db_key]["tv"].create_index("seasons.episodes.telegram.id")
            
            # TTL index for tokens - auto-delete after expires_at
            await self.dbs["tracking"]["tokens"].create_index("token_id", unique=True)
            await self.dbs["tracking"]["tokens"].create_index(
                "expires_at",
                expireAfterSeconds=0  # Delete when expires_at time is reached
            )
                
            LOGGER.info("✅ Created indexes for filename lookups and token TTL")
        except Exception as e:
            LOGGER.error(f"Error creating indexes: {e}")


    # -------------------------------
    # Helper Methods for Repeated Logic
    # -------------------------------
    def _get_sort_dict(self, sort_params: List[Tuple[str, str]]) -> Dict[str, int]:
        if sort_params:
            sort_field, sort_direction = sort_params[0]
            return {sort_field: DESCENDING if sort_direction.lower() == "desc" else ASCENDING}
        return {"updated_on": DESCENDING}

    async def _paginate_collection(
        self,
        collection_name: str,
        sort_dict: Dict[str, int],
        page: int,
        page_size: int,
        filter_dict: Optional[dict] = None
    ):
        filter_dict = filter_dict or {}
        skip = (page - 1) * page_size
        results = []
        dbs_checked = []
        total_count = 0

        db_counts = []
        for i in range(1, self.current_db_index + 1):
            db_key = f"storage_{i}"
            db = self.dbs[db_key]
            count = await db[collection_name].count_documents(filter_dict)
            db_counts.append((i, count))
            total_count += count

        start_db_index = None
        for db_index, count in reversed(db_counts):
            if skip < count:
                start_db_index = db_index
                break
            skip -= count

        if not start_db_index:
            return [], [], total_count

        for db_index, count in reversed(db_counts):
            if db_index < start_db_index:
                continue

            db_key = f"storage_{db_index}"
            db = self.dbs[db_key]
            dbs_checked.append(db_index)

            cursor = (
                db[collection_name]
                .find(filter_dict)
                .sort(sort_dict)
                .skip(skip if db_index == start_db_index else 0)
                .limit(page_size - len(results))
            )

            docs = await cursor.to_list(None)
            results.extend(docs)

            if len(results) >= page_size:
                break

        return results, dbs_checked, total_count



    async def _move_document(
        self, collection_name: str, document: dict, old_db_index: int
    ) -> bool:
        current_db_key = f"storage_{self.current_db_index}"
        old_db_key = f"storage_{old_db_index}"
        document["db_index"] = self.current_db_index
        try:
            await self.dbs[current_db_key][collection_name].insert_one(document)
            await self.dbs[old_db_key][collection_name].delete_one({"_id": document["_id"]})
            LOGGER.info(f"✅ Moved document {document.get('tmdb_id')} from {old_db_key} to {current_db_key}")
            return True
        except Exception as e:
            LOGGER.error(f"Error moving document to {current_db_key}: {e}")
            return False

    async def _handle_storage_error(self, func, *args, total_storage_dbs: int) -> Optional[Any]:
        next_db_index = (self.current_db_index % total_storage_dbs) + 1
        if next_db_index == 1:
            LOGGER.warning("⚠️ All storage databases are full! Add more.")
            return None
        self.current_db_index = next_db_index
        await self.update_current_db_index()
        LOGGER.info(f"Switched to storage_{self.current_db_index}")
        return await func(*args)


    # -------------------------------
    # Multi Database Method for insert/update/delete/list
    # -------------------------------

    async def insert_media(
        self, metadata_info: dict,
        channel: int, msg_id: int, size: str, name: str
    ) -> Optional[ObjectId]:
        
        if metadata_info['media_type'] == "movie":
            media = MovieSchema(
                tmdb_id=metadata_info['tmdb_id'],
                imdb_id=metadata_info['imdb_id'],
                db_index=self.current_db_index,
                title=metadata_info['title'],
                genres=metadata_info['genres'],
                tags=metadata_info.get('tags'),
                description=metadata_info['description'],
                rating=metadata_info['rate'],
                release_year=metadata_info['year'],
                poster=metadata_info['poster'],
                backdrop=metadata_info['backdrop'],
                logo=metadata_info['logo'],
                cast=metadata_info['cast'],
                runtime=metadata_info['runtime'],
                media_type=metadata_info['media_type'],
                telegram=[QualityDetail(
                    quality=metadata_info['quality'],
                    id=metadata_info['encoded_string'],
                    name=name,
                    size=size
                )]
            )
            result = await self.update_movie(media)
        else:
            tv_show = TVShowSchema(
                tmdb_id=metadata_info['tmdb_id'],
                imdb_id=metadata_info['imdb_id'],
                db_index=self.current_db_index,
                title=metadata_info['title'],
                genres=metadata_info['genres'],
                tags=metadata_info.get('tags'),
                description=metadata_info['description'],
                rating=metadata_info['rate'],
                release_year=metadata_info['year'],
                poster=metadata_info['poster'],
                backdrop=metadata_info['backdrop'],
                logo=metadata_info['logo'],
                cast=metadata_info['cast'],
                runtime=metadata_info['runtime'],
                media_type=metadata_info['media_type'],
                seasons=[Season(
                    season_number=metadata_info['season_number'],
                    episodes=[Episode(
                        episode_number=metadata_info['episode_number'],
                        title=metadata_info['episode_title'],
                        episode_backdrop=metadata_info['episode_backdrop'],
                        overview=metadata_info['episode_overview'],
                        released=metadata_info['episode_released'],
                        telegram=[QualityDetail(
                            quality=metadata_info['quality'],
                            id=metadata_info['encoded_string'],
                            name=name,
                            size=size
                        )]
                    )]
                )]
            )
            result = await self.update_tv_show(tv_show)
        
        # Update storage stats if insertion/update was successful
        if result:
            from asyncio import create_task
            create_task(self.update_storage_on_insert(metadata_info['quality'], size))
            
        return result

    async def update_movie(self, movie_data: MovieSchema) -> Optional[ObjectId]:
        try:
            movie_dict = movie_data.dict()
        except ValidationError as e:
            LOGGER.error(f"Validation error: {e}")
            return None

        imdb_id = movie_dict["imdb_id"]
        tmdb_id = movie_dict["tmdb_id"]
        title = movie_dict["title"]
        tags = movie_dict.get("tags")
        release_year = movie_dict["release_year"]

        quality_to_update = movie_dict["telegram"][0]
        target_quality = quality_to_update["quality"]

        current_db_key = f"storage_{self.current_db_index}"
        total_storage_dbs = len(self.dbs) - 1

        existing_movie = None
        existing_db_key = None
        existing_db_index = None

        for db_index in range(1, total_storage_dbs + 1):
            db_key = f"storage_{db_index}"
            movie = None

            if imdb_id:
                movie = await self.dbs[db_key]["movie"].find_one({"imdb_id": imdb_id})
            if not movie and tmdb_id:
                movie = await self.dbs[db_key]["movie"].find_one({"tmdb_id": tmdb_id})
            if not movie and title and release_year:
                movie = await self.dbs[db_key]["movie"].find_one({
                    "title": title,
                    "release_year": release_year
                })

            if movie:
                existing_movie = movie
                existing_db_key = db_key
                existing_db_index = db_index
                break

        # ---------------- INSERT NEW MOVIE ----------------
        if not existing_movie:
            try:
                movie_dict["db_index"] = self.current_db_index
                result = await self.dbs[current_db_key]["movie"].insert_one(movie_dict)
                return result.inserted_id
            except Exception as e:
                LOGGER.error(f"Insertion failed in {current_db_key}: {e}")
                if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                    return await self._handle_storage_error(self.update_movie, movie_data, total_storage_dbs=total_storage_dbs)
                return None

        # ---------------- UPDATE MOVIE ----------------
        movie_id = existing_movie["_id"]
        existing_qualities = existing_movie.get("telegram", [])

        if Telegram.REPLACE_MODE:
            # delete all same-quality entries
            to_delete = [q for q in existing_qualities if q.get("quality") == target_quality]

            for q in to_delete:
                try:
                    old_id = q.get("id")
                    if old_id:
                        decoded = await decode_string(old_id)
                        chat_id = int(f"-100{decoded['chat_id']}")
                        msg_id = int(decoded['msg_id'])
                        create_task(delete_message(chat_id, msg_id))
                except Exception as e:
                    LOGGER.error(f"Failed to delete old quality: {e}")

            existing_qualities = [
                q for q in existing_qualities if q.get("quality") != target_quality
            ]
            existing_qualities.append(quality_to_update)

        else:
            # allow duplicate qualities
            existing_qualities.append(quality_to_update)

        existing_movie["telegram"] = existing_qualities
        
        # Update tags if available and not present
        if tags:
            existing_movie["tags"] = tags
            
        existing_movie["updated_on"] = datetime.utcnow()

        if existing_db_index != self.current_db_index:
            try:
                if await self._move_document("movie", existing_movie, existing_db_index):
                    return movie_id
            except Exception as e:
                LOGGER.error(f"Error moving movie to {current_db_key}: {e}")
                if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                    return await self._handle_storage_error(self.update_movie, movie_data, total_storage_dbs=total_storage_dbs)

        try:
            await self.dbs[existing_db_key]["movie"].replace_one({"_id": movie_id}, existing_movie)
            return movie_id
        except Exception as e:
            LOGGER.error(f"Failed to update movie {tmdb_id} in {existing_db_key}: {e}")
            if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                return await self._handle_storage_error(self.update_movie, movie_data, total_storage_dbs=total_storage_dbs)

    async def update_tv_show(self, tv_show_data: TVShowSchema) -> Optional[ObjectId]:
        try:
            tv_show_dict = tv_show_data.dict()
        except ValidationError as e:
            LOGGER.error(f"Validation error: {e}")
            return None

        imdb_id = tv_show_dict.get("imdb_id")
        tmdb_id = tv_show_dict.get("tmdb_id")
        title = tv_show_dict["title"]
        tags = tv_show_dict.get("tags")
        release_year = tv_show_dict["release_year"]

        current_db_key = f"storage_{self.current_db_index}"
        total_storage_dbs = len(self.dbs) - 1

        existing_tv = None
        existing_db_key = None
        existing_db_index = None

        for db_index in range(1, total_storage_dbs + 1):
            db_key = f"storage_{db_index}"
            tv = None

            if imdb_id:
                tv = await self.dbs[db_key]["tv"].find_one({"imdb_id": imdb_id})
            if not tv and tmdb_id:
                tv = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
            if not tv and title and release_year:
                tv = await self.dbs[db_key]["tv"].find_one({
                    "title": title,
                    "release_year": release_year
                })

            if tv:
                existing_tv = tv
                existing_db_key = db_key
                existing_db_index = db_index
                break

        # ---------------- INSERT NEW TV ----------------
        if not existing_tv:
            try:
                tv_show_dict["db_index"] = self.current_db_index
                result = await self.dbs[current_db_key]["tv"].insert_one(tv_show_dict)
                return result.inserted_id
            except Exception as e:
                LOGGER.error(f"Insertion failed in {current_db_key}: {e}")
                if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                    return await self._handle_storage_error(self.update_tv_show, tv_show_data, total_storage_dbs=total_storage_dbs)
                return None

        # ---------------- UPDATE TV ----------------
        tv_id = existing_tv["_id"]

        for season in tv_show_dict["seasons"]:
            existing_season = next(
                (s for s in existing_tv["seasons"]
                if s["season_number"] == season["season_number"]),
                None
            )

            if not existing_season:
                existing_tv["seasons"].append(season)
                continue

            for episode in season["episodes"]:
                existing_episode = next(
                    (e for e in existing_season["episodes"]
                    if e["episode_number"] == episode["episode_number"]),
                    None
                )

                if not existing_episode:
                    existing_season["episodes"].append(episode)
                    continue

                # Update the episode timestamp when qualities change
                existing_episode["updated_on"] = datetime.utcnow().isoformat()

                existing_episode.setdefault("telegram", [])

                for quality in episode["telegram"]:
                    target_quality = quality.get("quality")

                    if Telegram.REPLACE_MODE:
                        to_delete = [
                            q for q in existing_episode["telegram"]
                            if q.get("quality") == target_quality
                        ]

                        for q in to_delete:
                            try:
                                old_id = q.get("id")
                                if old_id:
                                    decoded = await decode_string(old_id)
                                    chat_id = int(f"-100{decoded['chat_id']}")
                                    msg_id = int(decoded['msg_id'])
                                    create_task(delete_message(chat_id, msg_id))
                            except Exception as e:
                                LOGGER.error(f"Failed to delete old quality: {e}")

                        existing_episode["telegram"] = [
                            q for q in existing_episode["telegram"]
                            if q.get("quality") != target_quality
                        ]
                        existing_episode["telegram"].append(quality)

                    else:
                        existing_episode["telegram"].append(quality)

        # Update tags if available
        if tags:
            existing_tv["tags"] = tags

        existing_tv["updated_on"] = datetime.utcnow()
        
        # Calculate and update dub/sub counts
        # SUB = total episodes, DUB = episodes with dual audio
        # Only log changes to avoid spam when re-uploading
        from Backend.helper.language_detector import is_dub, detect_languages
        all_episodes = set()
        dual_audio_episodes = set()
        
        # Get previous state for comparison
        prev_dub_set = set()
        prev_all_set = set()
        
        # Build previous state from existing counts (if available)
        for season in existing_tv.get("seasons", []):
            season_num = season.get("season_number")
            for episode in season.get("episodes", []):
                episode_num = episode.get("episode_number")
                telegram_files = episode.get("telegram", [])
                
                if telegram_files:
                    episode_key = (season_num, episode_num)
                    # All episodes count towards SUB
                    all_episodes.add(episode_key)
                    
                    # Only dual audio episodes count towards DUB
                    sample_file = telegram_files[0]
                    filename = sample_file.get("name", "")
                    
                    # Detect languages and classify
                    detected_langs = detect_languages(filename)
                    is_dual_audio = is_dub(filename)
                    
                    if is_dual_audio:
                        dual_audio_episodes.add(episode_key)
                        # Only log if this is from the new upload (in tv_show_dict)
                        for new_season in tv_show_dict.get("seasons", []):
                            if new_season.get("season_number") == season_num:
                                for new_ep in new_season.get("episodes", []):
                                    if new_ep.get("episode_number") == episode_num:
                                        LOGGER.info(f"📺 {tv_show_dict.get('title')} S{season_num:02d}E{episode_num:02d} → 🎙️ DUB (Languages: {', '.join(detected_langs) if detected_langs else 'N/A'})")
                                        break
                                break
                    else:
                        # Only log if this is from the new upload
                        for new_season in tv_show_dict.get("seasons", []):
                            if new_season.get("season_number") == season_num:
                                for new_ep in new_season.get("episodes", []):
                                    if new_ep.get("episode_number") == episode_num:
                                        LOGGER.info(f"📺 {tv_show_dict.get('title')} S{season_num:02d}E{episode_num:02d} → 📝 SUB (Languages: {', '.join(detected_langs) if detected_langs else 'N/A'})")
                                        break
                                break
        
        prev_dub = existing_tv.get("total_dub", 0)
        prev_sub = existing_tv.get("total_sub", 0)
        
        existing_tv["total_dub"] = len(dual_audio_episodes)
        existing_tv["total_sub"] = len(all_episodes)
        
        # Log summary if counts changed
        if prev_dub != existing_tv["total_dub"] or prev_sub != existing_tv["total_sub"]:
            LOGGER.info(f"✅ {tv_show_dict.get('title')} - Audio Counts: SUB: {existing_tv['total_sub']} (Total Episodes), DUB: {existing_tv['total_dub']} (Dual Audio)")

        # ---------------- MOVE DB IF NEEDED ----------------
        if existing_db_index != self.current_db_index:
            try:
                if await self._move_document("tv", existing_tv, existing_db_index):
                    return tv_id
            except Exception as e:
                LOGGER.error(f"Error moving TV show to {current_db_key}: {e}")
                if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                    return await self._handle_storage_error(self.update_tv_show, tv_show_data, total_storage_dbs=total_storage_dbs)
            return tv_id

        try:
            await self.dbs[existing_db_key]["tv"].replace_one({"_id": tv_id}, existing_tv)
            return tv_id
        except Exception as e:
            LOGGER.error(f"Failed to update TV show {tmdb_id} in {existing_db_key}: {e}")
            if any(keyword in str(e).lower() for keyword in ["storage", "quota"]):
                return await self._handle_storage_error(self.update_tv_show, tv_show_data, total_storage_dbs=total_storage_dbs)
    
    async def calculate_tv_dub_sub_counts(self, tmdb_id: int, db_index: int) -> Tuple[int, int]:
        """
        Calculate total dub and sub counts for a TV show across all seasons and episodes.
        
        IMPORTANT LOGIC:
        - SUB = Total number of unique episodes (all episodes count here)
        - DUB = Number of episodes with dual/multi audio (Japanese + other language)
        
        An episode with dual audio is counted in BOTH SUB and DUB!
        
        Args:
            tmdb_id: TMDB ID of the TV show
            db_index: Database index where the show is stored
            
        Returns:
            Tuple of (total_dub, total_sub)
        """
        from Backend.helper.language_detector import is_dub
        
        db_key = f"storage_{db_index}"
        tv_show = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
        
        if not tv_show:
            return 0, 0
        
        # Track all unique episodes and which ones are dual audio
        all_episodes = set()  # All episodes (for SUB count)
        dual_audio_episodes = set()  # Episodes with dual audio (for DUB count)
        
        for season in tv_show.get("seasons", []):
            season_num = season.get("season_number")
            for episode in season.get("episodes", []):
                episode_num = episode.get("episode_number")
                telegram_files = episode.get("telegram", [])
                
                if not telegram_files:
                    continue
                
                episode_key = (season_num, episode_num)
                
                # All episodes count towards SUB (total episodes)
                all_episodes.add(episode_key)
                
                # Check if this episode has dual audio
                sample_file = telegram_files[0]
                filename = sample_file.get("name", "")
                
                # If dual audio (Japanese + other language), add to DUB count
                if is_dub(filename):
                    dual_audio_episodes.add(episode_key)
        
        # SUB = total episodes, DUB = dual audio episodes
        return len(dual_audio_episodes), len(all_episodes)
    
    async def update_tv_dub_sub_counts(self, tmdb_id: int, db_index: int) -> bool:
        """
        Calculate and update dub/sub counts for a TV show in the database.
        
        Args:
            tmdb_id: TMDB ID of the TV show
            db_index: Database index where the show is stored
            
        Returns:
            True if update was successful, False otherwise
        """
        total_dub, total_sub = await self.calculate_tv_dub_sub_counts(tmdb_id, db_index)
        
        db_key = f"storage_{db_index}"
        try:
            result = await self.dbs[db_key]["tv"].update_one(
                {"tmdb_id": tmdb_id},
                {"$set": {"total_dub": total_dub, "total_sub": total_sub}}
            )
            return result.modified_count > 0
        except Exception as e:
            LOGGER.error(f"Failed to update dub/sub counts for TV show {tmdb_id}: {e}")
            return False
    
    async def update_media_tags(self, tmdb_id: int, tags: list, media_type: str, db_index: int) -> bool:
        """Update tags for a specific media item."""
        db_key = f"storage_{db_index}"
        collection = "tv" if media_type == "tv" else "movie"
        try:
            await self.dbs[db_key][collection].update_one(
                {"tmdb_id": tmdb_id},
                {"$set": {"tags": tags}}
            )
            return True
        except Exception as e:
            LOGGER.error(f"Failed to update tags for {media_type} {tmdb_id}: {e}")
            return False

    async def get_all_media(self, media_type: str):
        """Yield all media items of a specific type across all storage DBs."""
        total_storage_dbs = len(self.dbs) - 1
        collection = "tv" if media_type == "tv" else "movie"
        
        for db_index in range(1, total_storage_dbs + 1):
            db_key = f"storage_{db_index}"
            # Use find to get a cursor and yield documents
            cursor = self.dbs[db_key][collection].find({}, {"tmdb_id": 1, "title": 1, "db_index": 1})
            async for doc in cursor:
                yield doc
    
    async def sort_movies(self, sort_params, page, page_size, genre_filter=None):
        sort_dict = self._get_sort_dict(sort_params)
        # Case-insensitive genre filter using regex
        if genre_filter:
            filter_dict = {"genres": {"$elemMatch": {"$regex": f"^{genre_filter}$", "$options": "i"}}}
        else:
            filter_dict = {}
        results, dbs_checked, total_count = await self._paginate_collection(
            "movie", sort_dict, page, page_size, filter_dict=filter_dict
        )
        total_pages = (total_count + page_size - 1) // page_size
        return {
            "total_count": total_count,
            "total_pages": total_pages,
            "databases_checked": dbs_checked,
            "current_page": page,
            "movies": [convert_objectid_to_str(result) for result in results],
        }

    async def sort_tv_shows(self, sort_params, page, page_size, genre_filter=None):
        sort_dict = self._get_sort_dict(sort_params)
        # Case-insensitive genre filter using regex
        if genre_filter:
            filter_dict = {"genres": {"$elemMatch": {"$regex": f"^{genre_filter}$", "$options": "i"}}}
        else:
            filter_dict = {}
        results, dbs_checked, total_count = await self._paginate_collection(
            "tv", sort_dict, page, page_size, filter_dict=filter_dict
        )
        total_pages = (total_count + page_size - 1) // page_size
        return {
            "total_count": total_count,
            "total_pages": total_pages,
            "databases_checked": dbs_checked,
            "current_page": page,
            "tv_shows": [convert_objectid_to_str(result) for result in results],
        }



    async def search_documents(
            self, 
            query: str, 
            page: int, 
            page_size: int
        ) -> dict:

            skip = (page - 1) * page_size
            
            words = query.split()
            regex_query = {
                '$regex': '.*' + '.*'.join(words) + '.*', 
                '$options': 'i'
            }
            
            tv_pipeline = [
                {"$match": {"$or": [
                    {"title": regex_query},
                    {"seasons.episodes.telegram.name": regex_query}
                ]}},
                {"$project": {
                    "_id": 1, "tmdb_id": 1, "title": 1, "genres": 1, "rating": 1, "imdb_id": 1,
                    "release_year": 1, "poster": 1, "backdrop": 1, "description": 1, "logo": 1,
                    "media_type": 1, "db_index": 1
                }}
            ]
            
            movie_pipeline = [
                {"$match": {"$or": [
                    {"title": regex_query},
                    {"telegram.name": regex_query}
                ]}},
                {"$project": {
                    "_id": 1, "tmdb_id": 1, "title": 1, "genres": 1, "rating": 1,
                    "release_year": 1, "poster": 1, "backdrop": 1, "description": 1,
                    "media_type": 1, "db_index": 1, "imdb_id": 1, "logo": 1
                }}
            ]
            
            results = []
            dbs_checked = []
            
            active_db_key = f"storage_{self.current_db_index}"
            active_db = self.dbs[active_db_key]
            dbs_checked.append(self.current_db_index)
            
            tv_results = await active_db["tv"].aggregate(tv_pipeline).to_list(None)
            movie_results = await active_db["movie"].aggregate(movie_pipeline).to_list(None)
            combined = tv_results + movie_results
            results.extend(combined)
            
            if len(results) < page_size:
                previous_db_index = self.current_db_index - 1
                while previous_db_index > 0 and len(results) < page_size:
                    prev_db_key = f"storage_{previous_db_index}"
                    prev_db = self.dbs[prev_db_key]
                    tv_results_prev = await prev_db["tv"].aggregate(tv_pipeline).to_list(None)
                    movie_results_prev = await prev_db["movie"].aggregate(movie_pipeline).to_list(None)
                    combined_prev = tv_results_prev + movie_results_prev
                    results.extend(combined_prev)
                    dbs_checked.append(previous_db_index)
                    previous_db_index -= 1

            total_count = 0
            for db_index in dbs_checked:
                key = f"storage_{db_index}"
                db = self.dbs[key]
                tv_count = await db["tv"].count_documents({
                    "$or": [
                        {"title": regex_query},
                        {"seasons.episodes.telegram.name": regex_query}
                    ]
                })
                movie_count = await db["movie"].count_documents({
                    "$or": [
                        {"title": regex_query},
                        {"telegram.name": regex_query}
                    ]
                })
                total_count += (tv_count + movie_count)
            
            paged_results = results[skip:skip + page_size]

            return {
                "total_count": total_count,
                "results": [convert_objectid_to_str(doc) for doc in paged_results]
            }


    async def get_media_details(
        self, tmdb_id: int, db_index: int,
        season_number: Optional[int] = None, episode_number: Optional[int] = None
    ) -> Optional[dict]:
        db_key = f"storage_{db_index}"
        if episode_number is not None and season_number is not None:
            tv_show = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
            if not tv_show:
                return None
            for season in tv_show.get("seasons", []):
                if season.get("season_number") == season_number:
                    for episode in season.get("episodes", []):
                        if episode.get("episode_number") == episode_number:
                            details = convert_objectid_to_str(episode)
                            details.update({
                                "tmdb_id": tmdb_id,
                                "type": "tv",
                                "season_number": season_number,
                                "episode_number": episode_number,
                                "backdrop": episode.get("episode_backdrop")
                            })
                            return details
            return None

        elif season_number is not None:
            tv_show = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
            if not tv_show:
                return None
            for season in tv_show.get("seasons", []):
                if season.get("season_number") == season_number:
                    details = convert_objectid_to_str(season)
                    details.update({
                        "tmdb_id": tmdb_id,
                        "type": "tv",
                        "season_number": season_number
                    })
                    return details
            return None

        else:
            tv_doc = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
            if tv_doc:
                tv_doc = convert_objectid_to_str(tv_doc)
                tv_doc["type"] = "tv"
                return tv_doc
            movie_doc = await self.dbs[db_key]["movie"].find_one({"tmdb_id": tmdb_id})
            if movie_doc:
                movie_doc = convert_objectid_to_str(movie_doc)
                movie_doc["type"] = "movie"
                return movie_doc
            return None


    # -------------------------------
    # DB Method for Edit Post
    # -------------------------------


    async def get_document(self, media_type: str, tmdb_id: int, db_index: int) -> Optional[Dict[str, Any]]:
        db_key = f"storage_{db_index}"
        if media_type.lower() in ["tv", "series"]:
            collection_name = "tv"
        else:
            collection_name = "movie"
        document = await self.dbs[db_key][collection_name].find_one({"tmdb_id": int(tmdb_id)})
        return convert_objectid_to_str(document) if document else None

    async def update_document(
        self, media_type: str, tmdb_id: int, db_index: int, update_data: Dict[str, Any]
    ):
        update_data.pop('_id', None)
        db_key = f"storage_{db_index}"
        if media_type.lower() in ["tv", "series"]:
            collection_name = "tv"
        else:
            collection_name = "movie"
        collection = self.dbs[db_key][collection_name]

        try:
            result = await collection.update_one({"tmdb_id": int(tmdb_id)}, {"$set": update_data})

            return result.modified_count > 0

        except Exception as e:
            err_str = str(e).lower()
            LOGGER.error(f"Error updating document in {db_key}: {e}")
            if "storage" in err_str or "quota" in err_str:
                total_storage_dbs = len(self.dbs) - 1
                db_index_int = int(db_index)
                next_db_index = (db_index_int % total_storage_dbs) + 1
                if next_db_index == 1:
                    LOGGER.warning("⚠️ All storage databases are full! Add more.")
                    return False

                new_db_key = f"storage_{next_db_index}"
                LOGGER.info(f"Switching from {db_key} to {new_db_key} due to storage error.")

                try:
                    old_doc = await self.dbs[db_key][collection_name].find_one({"tmdb_id": int(tmdb_id)})
                    if not old_doc:
                        LOGGER.error(f"Document with tmdb_id {tmdb_id} not found in {db_key} during migration.")
                        return False

                    old_doc.update(update_data)
                    old_doc["db_index"] = next_db_index
                    old_doc.pop("_id", None)
                    insert_result = await self.dbs[new_db_key][collection_name].insert_one(old_doc)
                    LOGGER.info(f"Inserted document {insert_result.inserted_id} into {new_db_key}")
                    await self.dbs[db_key][collection_name].delete_one({"tmdb_id": int(tmdb_id)})
                    LOGGER.info(f"Deleted document tmdb_id {tmdb_id} from {db_key}")
                    self.current_db_index = next_db_index
                    await self.update_current_db_index()
                    LOGGER.info(f"Switched to {new_db_key} and document migrated successfully.")
                    return True

                except Exception as migrate_error:
                    LOGGER.error(f"Error migrating document tmdb_id {tmdb_id} to {new_db_key}: {migrate_error}")
                    return False
            raise

    async def delete_document(self, media_type: str, tmdb_id: int, db_index: int) -> bool:
        db_key = f"storage_{db_index}"

        if media_type == "Movie":
            doc = await self.dbs[db_key]["movie"].find_one({"tmdb_id": tmdb_id})
            if doc and "telegram" in doc:
                for quality in doc["telegram"]:
                    try:
                        old_id = quality.get("id")
                        if old_id:
                            decoded_data = await decode_string(old_id)
                            chat_id = int(f"-100{decoded_data['chat_id']}")
                            msg_id = int(decoded_data['msg_id'])
                            create_task(delete_message(chat_id, msg_id))
                    except Exception as e:
                        LOGGER.error(f"Failed to queue file for deletion: {e}")
            
            result = await self.dbs[db_key]["movie"].delete_one({"tmdb_id": tmdb_id})
        else:
            doc = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
            if doc and "seasons" in doc:
                for season in doc["seasons"]:
                    for episode in season.get("episodes", []):
                        for quality in episode.get("telegram", []):
                            try:
                                old_id = quality.get("id")
                                if old_id:
                                    decoded_data = await decode_string(old_id)
                                    chat_id = int(f"-100{decoded_data['chat_id']}")
                                    msg_id = int(decoded_data['msg_id'])
                                    create_task(delete_message(chat_id, msg_id))
                            except Exception as e:
                                LOGGER.error(f"Failed to queue file for deletion: {e}")
            
            result = await self.dbs[db_key]["tv"].delete_one({"tmdb_id": tmdb_id})
        
        if result.deleted_count > 0:
            LOGGER.info(f"{media_type} with tmdb_id {tmdb_id} deleted successfully.")
            return True
        LOGGER.info(f"No document found with tmdb_id {tmdb_id}.")
        return False

    async def delete_movie_quality(self, tmdb_id: int, db_index: int, id: str) -> bool:
        db_key = f"storage_{db_index}"
        movie = await self.dbs[db_key]["movie"].find_one({"tmdb_id": tmdb_id})
        
        if not movie or "telegram" not in movie:
            return False

        for q in movie["telegram"]:
            if q.get("id") == id:
                try:
                    old_id = q.get("id")
                    if old_id:
                        decoded_data = await decode_string(old_id)
                        chat_id = int(f"-100{decoded_data['chat_id']}")
                        msg_id = int(decoded_data['msg_id'])
                        create_task(delete_message(chat_id, msg_id))
                except Exception as e:
                    LOGGER.error(f"Failed to queue file for deletion: {e}")
                break
        
        original_len = len(movie["telegram"])
        movie["telegram"] = [q for q in movie["telegram"] if q.get("id") != id]
        
        if len(movie["telegram"]) == original_len:
            return False
        
        movie['updated_on'] = datetime.utcnow()
        result = await self.dbs[db_key]["movie"].replace_one({"tmdb_id": tmdb_id}, movie)
        return result.modified_count > 0

    async def delete_tv_episode(self, tmdb_id: int, db_index: int, season_number: int, episode_number: int) -> bool:
        db_key = f"storage_{db_index}"
        tv = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
        
        if not tv or "seasons" not in tv:
            return False
        
        found = False
        for season in tv["seasons"]:
            if season.get("season_number") == season_number:
                for ep in season["episodes"]:
                    if ep.get("episode_number") == episode_number:
                        for quality in ep.get("telegram", []):
                            try:
                                old_id = quality.get("id")
                                if old_id:
                                    decoded_data = await decode_string(old_id)
                                    chat_id = int(f"-100{decoded_data['chat_id']}")
                                    msg_id = int(decoded_data['msg_id'])
                                    create_task(delete_message(chat_id, msg_id))
                            except Exception as e:
                                LOGGER.error(f"Failed to queue file for deletion: {e}")
                        break
                
                original_len = len(season["episodes"])
                season["episodes"] = [ep for ep in season["episodes"] if ep.get("episode_number") != episode_number]
                found = original_len > len(season["episodes"])
                break
        
        if not found:
            return False
        
        tv['updated_on'] = datetime.utcnow()
        result = await self.dbs[db_key]["tv"].replace_one({"tmdb_id": tmdb_id}, tv)
        return result.modified_count > 0

    async def delete_tv_season(self, tmdb_id: int, db_index: int, season_number: int) -> bool:
        db_key = f"storage_{db_index}"
        tv = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
        
        if not tv or "seasons" not in tv:
            return False
        
        for season in tv["seasons"]:
            if season.get("season_number") == season_number:
                for episode in season.get("episodes", []):
                    for quality in episode.get("telegram", []):
                        try:
                            old_id = quality.get("id")
                            if old_id:
                                decoded_data = await decode_string(old_id)
                                chat_id = int(f"-100{decoded_data['chat_id']}")
                                msg_id = int(decoded_data['msg_id'])
                                create_task(delete_message(chat_id, msg_id))
                        except Exception as e:
                            LOGGER.error(f"Failed to queue file for deletion: {e}")
                break
        
        original_len = len(tv["seasons"])
        tv["seasons"] = [s for s in tv["seasons"] if s.get("season_number") != season_number]
        
        if len(tv["seasons"]) == original_len:
            return False
        
        tv['updated_on'] = datetime.utcnow()
        result = await self.dbs[db_key]["tv"].replace_one({"tmdb_id": tmdb_id}, tv)
        return result.modified_count > 0

    async def delete_tv_quality(self, tmdb_id: int, db_index: int, season_number: int, episode_number: int, id: str) -> bool:
        db_key = f"storage_{db_index}"
        tv = await self.dbs[db_key]["tv"].find_one({"tmdb_id": tmdb_id})
        
        if not tv or "seasons" not in tv:
            return False
        
        found = False
        for season in tv["seasons"]:
            if season.get("season_number") == season_number:
                for episode in season["episodes"]:
                    if episode.get("episode_number") == episode_number and "telegram" in episode:
                        for q in episode["telegram"]:
                            if q.get("id") == id:
                                try:
                                    old_id = q.get("id")
                                    if old_id:
                                        decoded_data = await decode_string(old_id)
                                        chat_id = int(f"-100{decoded_data['chat_id']}")
                                        msg_id = int(decoded_data['msg_id'])
                                        create_task(delete_message(chat_id, msg_id))
                                except Exception as e:
                                    LOGGER.error(f"Failed to queue file for deletion: {e}")
                                break
                        
                        original_len = len(episode["telegram"])
                        episode["telegram"] = [q for q in episode["telegram"] if q.get("id") != id]
                        found = original_len > len(episode["telegram"])
                        break
        
        if not found:
            return False
        tv['updated_on'] = datetime.utcnow()
        result = await self.dbs[db_key]["tv"].replace_one({"tmdb_id": tmdb_id}, tv)
        return result.modified_count > 0


    # Get per-DB statistics (movies, tv shows, used size, etc.)
    async def get_database_stats(self):
        stats = []
        for key in self.dbs.keys():
            if key.startswith("storage_"):
                db = self.dbs[key]
                movie_count = await db["movie"].count_documents({})
                tv_count = await db["tv"].count_documents({})
                db_stats = await db.command("dbstats")
                stats.append({
                    "db_name": key,
                    "movie_count": movie_count,
                    "tv_count": tv_count,
                    "storageSize": db_stats.get("storageSize", 0),
                    "dataSize": db_stats.get("dataSize", 0)
                })
        return stats

    # -------------------------------
    # Force Subscribe Methods
    # -------------------------------
    
    async def add_fsub_channel(self, channel_id: int, channel_title: str, invite_link: str) -> bool:
        """Add a force subscribe channel."""
        try:
            await self.dbs["tracking"]["fsub_channels"].update_one(
                {"channel_id": channel_id},
                {"$set": {
                    "channel_id": channel_id,
                    "channel_title": channel_title,
                    "invite_link": invite_link,
                    "added_on": datetime.utcnow()
                }},
                upsert=True
            )
            LOGGER.info(f"Added fsub channel: {channel_title} ({channel_id})")
            return True
        except Exception as e:
            LOGGER.error(f"Error adding fsub channel: {e}")
            return False

    async def remove_fsub_channel(self, channel_id: int) -> bool:
        """Remove a force subscribe channel."""
        try:
            result = await self.dbs["tracking"]["fsub_channels"].delete_one({"channel_id": channel_id})
            if result.deleted_count > 0:
                LOGGER.info(f"Removed fsub channel: {channel_id}")
                return True
            return False
        except Exception as e:
            LOGGER.error(f"Error removing fsub channel: {e}")
            return False

    async def get_fsub_channels(self) -> list:
        """Get all force subscribe channels."""
        try:
            cursor = self.dbs["tracking"]["fsub_channels"].find({})
            channels = await cursor.to_list(length=None)
            return [convert_objectid_to_str(ch) for ch in channels]
        except Exception as e:
            LOGGER.error(f"Error getting fsub channels: {e}")
            return []

    async def add_join_request(self, user_id: int, channel_id: int, username: str = None) -> bool:
        """Add a join request from user for a channel."""
        try:
            await self.dbs["tracking"]["join_requests"].update_one(
                {"user_id": user_id, "channel_id": channel_id},
                {"$set": {
                    "user_id": user_id,
                    "channel_id": channel_id,
                    "username": username,
                    "status": "pending",
                    "requested_on": datetime.utcnow()
                }},
                upsert=True
            )
            LOGGER.info(f"Added join request: user {user_id} for channel {channel_id}")
            return True
        except Exception as e:
            LOGGER.error(f"Error adding join request: {e}")
            return False

    async def approve_join_request(self, user_id: int, channel_id: int) -> bool:
        """Approve a join request."""
        try:
            result = await self.dbs["tracking"]["join_requests"].update_one(
                {"user_id": user_id, "channel_id": channel_id},
                {"$set": {"status": "approved", "approved_on": datetime.utcnow()}}
            )
            return result.modified_count > 0
        except Exception as e:
            LOGGER.error(f"Error approving join request: {e}")
            return False

    async def get_user_requests(self, user_id: int) -> list:
        """Get all requests from a specific user."""
        try:
            cursor = self.dbs["tracking"]["join_requests"].find({"user_id": user_id})
            requests = await cursor.to_list(length=None)
            return [convert_objectid_to_str(req) for req in requests]
        except Exception as e:
            LOGGER.error(f"Error getting user requests: {e}")
            return []

    async def get_pending_requests(self, channel_id: int = None) -> list:
        """Get pending join requests, optionally filtered by channel."""
        try:
            query = {"status": "pending"}
            if channel_id:
                query["channel_id"] = channel_id
            cursor = self.dbs["tracking"]["join_requests"].find(query)
            requests = await cursor.to_list(length=None)
            return [convert_objectid_to_str(req) for req in requests]
        except Exception as e:
            LOGGER.error(f"Error getting pending requests: {e}")
            return []

    async def get_filename_by_id(self, encoded_id: str) -> Optional[str]:
        """Get original filename from database using encoded telegram ID"""
        try:
            total_storage_dbs = len(self.dbs) - 1
            
            # Search in all storage databases
            for db_index in range(1, total_storage_dbs + 1):
                db_key = f"storage_{db_index}"
                
                # Search in movies
                movie = await self.dbs[db_key]["movie"].find_one(
                    {"telegram.id": encoded_id},
                    {"telegram.$": 1}
                )
                if movie and "telegram" in movie:
                    return movie["telegram"][0].get("name")
                
                # Search in TV shows
                tv = await self.dbs[db_key]["tv"].find_one(
                    {"seasons.episodes.telegram.id": encoded_id}
                )
                if tv and "seasons" in tv:
                    for season in tv["seasons"]:
                        for episode in season.get("episodes", []):
                            for quality in episode.get("telegram", []):
                                if quality.get("id") == encoded_id:
                                    return quality.get("name")
            
            return None
        except Exception as e:
            LOGGER.error(f"Error getting filename by ID: {e}")
            return None

    async def get_channel_users(self, channel_id: int) -> dict:
        """Get users who joined or requested to join a channel."""
        try:
            cursor = self.dbs["tracking"]["join_requests"].find({"channel_id": channel_id})
            requests = await cursor.to_list(length=None)
            return {
                "pending": [r for r in requests if r.get("status") == "pending"],
                "approved": [r for r in requests if r.get("status") == "approved"]
            }
        except Exception as e:
            LOGGER.error(f"Error getting channel users: {e}")
            return {"pending": [], "approved": []}

    # -------------------------------
    # Storage & Bandwidth Tracking
    # -------------------------------
    
    QUALITY_CATEGORIES = ["480p", "720p", "1080p", "WEB-DL", "HDRip"]
    
    def _parse_size_to_bytes(self, size_str: str) -> int:
        """Parse size string like '1.23GB' or '1.2 GB' to bytes."""
        if not size_str or not isinstance(size_str, str):
            return 0
        try:
            size_str = size_str.strip().upper()
            # Use regex to extract number and unit (handles both "1.23GB" and "1.23 GB")
            import re
            match = re.match(r'^([\d.]+)\s*(B|KB|MB|GB|TB|PB)$', size_str)
            if not match:
                return 0
            
            num = float(match.group(1))
            unit = match.group(2)
            
            multipliers = {
                'B': 1,
                'KB': 1024,
                'MB': 1024 ** 2,
                'GB': 1024 ** 3,
                'TB': 1024 ** 4,
                'PB': 1024 ** 5
            }
            return int(num * multipliers.get(unit, 1))
        except:
            return 0
    
    def _classify_quality(self, quality_str: str) -> str:
        """Classify quality string to category."""
        if not quality_str:
            return "other"
        quality_upper = quality_str.upper()
        for cat in self.QUALITY_CATEGORIES:
            if cat.upper() in quality_upper:
                return cat
        return "other"
    
    def _format_bytes(self, bytes_val: int) -> str:
        """Format bytes to human readable string."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_val < 1024:
                return f"{bytes_val:.2f} {unit}"
            bytes_val /= 1024
        return f"{bytes_val:.2f} PB"
    
    async def calculate_quality_storage(self) -> dict:
        """
        Calculate total storage size by quality across all databases.
        Returns dict with quality breakdown and total.
        """
        quality_sizes = {q: 0 for q in self.QUALITY_CATEGORIES}
        quality_sizes["other"] = 0
        quality_counts = {q: 0 for q in self.QUALITY_CATEGORIES}
        quality_counts["other"] = 0
        total_size = 0
        total_files = 0
        
        for db_index in range(1, self.current_db_index + 1):
            db_key = f"storage_{db_index}"
            db = self.dbs[db_key]
            
            # Process movies
            async for movie in db["movie"].find({}):
                for tg in movie.get("telegram", []):
                    size_bytes = self._parse_size_to_bytes(tg.get("size", ""))
                    quality_cat = self._classify_quality(tg.get("quality", ""))
                    quality_sizes[quality_cat] += size_bytes
                    quality_counts[quality_cat] += 1
                    total_size += size_bytes
                    total_files += 1
            
            # Process TV shows
            async for tv in db["tv"].find({}):
                for season in tv.get("seasons", []):
                    for episode in season.get("episodes", []):
                        for tg in episode.get("telegram", []):
                            size_bytes = self._parse_size_to_bytes(tg.get("size", ""))
                            quality_cat = self._classify_quality(tg.get("quality", ""))
                            quality_sizes[quality_cat] += size_bytes
                            quality_counts[quality_cat] += 1
                            total_size += size_bytes
                            total_files += 1
        
        # Save stats to tracking DB
        stats_doc = {
            "_id": "storage_stats",
            "quality_sizes": quality_sizes,
            "quality_counts": quality_counts,
            "total_size": total_size,
            "total_files": total_files,
            "quality_sizes_readable": {k: self._format_bytes(v) for k, v in quality_sizes.items()},
            "total_size_readable": self._format_bytes(total_size),
            "last_calculated": datetime.utcnow()
        }
        
        await self.dbs["tracking"]["stats"].replace_one(
            {"_id": "storage_stats"},
            stats_doc,
            upsert=True
        )
        
        LOGGER.info(f"📊 Storage stats calculated: {total_files} files, {self._format_bytes(total_size)} total")
        return stats_doc
    
    async def get_storage_stats(self) -> Optional[dict]:
        """Get cached storage stats from tracking DB."""
        return await self.dbs["tracking"]["stats"].find_one({"_id": "storage_stats"})
    
    async def update_storage_on_insert(self, quality: str, size: str):
        """Update storage stats when a new file is inserted."""
        size_bytes = self._parse_size_to_bytes(size)
        quality_cat = self._classify_quality(quality)
        
        await self.dbs["tracking"]["stats"].update_one(
            {"_id": "storage_stats"},
            {
                "$inc": {
                    f"quality_sizes.{quality_cat}": size_bytes,
                    f"quality_counts.{quality_cat}": 1,
                    "total_size": size_bytes,
                    "total_files": 1
                }
            },
            upsert=True
        )
    
    async def log_download(self, quality: str, size: "Union[int, str]"):
        """Log a download event for bandwidth tracking."""
        if isinstance(size, (int, float)):
            size_bytes = int(size)
        else:
            size_bytes = self._parse_size_to_bytes(size)
            
        quality_cat = self._classify_quality(quality)
        year_month = datetime.utcnow().strftime("%Y-%m")
        
        await self.dbs["tracking"]["bandwidth"].update_one(
            {"_id": year_month},
            {
                "$inc": {
                    f"quality_bandwidth.{quality_cat}": size_bytes,
                    "total_bandwidth": size_bytes,
                    "download_count": 1
                },
                "$setOnInsert": {
                    "year_month": year_month,
                    "created_at": datetime.utcnow()
                }
            },
            upsert=True
        )
    
    async def get_bandwidth_stats(self, months: int = 12) -> list:
        """Get bandwidth stats for the last N months."""
        cursor = self.dbs["tracking"]["bandwidth"].find().sort("_id", DESCENDING).limit(months)
        stats = await cursor.to_list(length=months)
        
        # Add readable format
        for stat in stats:
            stat["total_bandwidth_readable"] = self._format_bytes(stat.get("total_bandwidth", 0))
            if "quality_bandwidth" in stat:
                stat["quality_bandwidth_readable"] = {
                    k: self._format_bytes(v) for k, v in stat["quality_bandwidth"].items()
                }
        
        return stats
    
    async def get_current_month_bandwidth(self) -> Optional[dict]:
        """Get bandwidth stats for current month."""
        year_month = datetime.utcnow().strftime("%Y-%m")
        stat = await self.dbs["tracking"]["bandwidth"].find_one({"_id": year_month})
        if stat:
            stat["total_bandwidth_readable"] = self._format_bytes(stat.get("total_bandwidth", 0))
            if "quality_bandwidth" in stat:
                stat["quality_bandwidth_readable"] = {
                    k: self._format_bytes(v) for k, v in stat["quality_bandwidth"].items()
                }
        return stat

    # -------------------------------
    # Token Management for Time-Based URLs
    # -------------------------------
    async def store_token(self, token_id: str, file_id: str, expires_at: datetime) -> bool:
        """Store a token -> file_id mapping with expiry time."""
        try:
            await self.dbs["tracking"]["tokens"].update_one(
                {"token_id": token_id},
                {
                    "$set": {
                        "file_id": file_id,
                        "expires_at": expires_at,
                        "created_at": datetime.utcnow()
                    }
                },
                upsert=True
            )
            return True
        except Exception as e:
            LOGGER.error(f"Failed to store token: {e}")
            return False
    
    async def get_token_file_id(self, token_id: str) -> Optional[str]:
        """Get file_id for a token. Returns None if not found or expired."""
        try:
            token = await self.dbs["tracking"]["tokens"].find_one({"token_id": token_id})
            if token and token.get("expires_at") > datetime.utcnow():
                return token.get("file_id")
            return None
        except Exception as e:
            LOGGER.error(f"Failed to get token: {e}")
            return None

