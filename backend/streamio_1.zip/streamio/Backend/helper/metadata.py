# metadata.py
import asyncio
import traceback
import PTN
import re
from re import compile, IGNORECASE
from Backend.helper.imdb import get_detail, get_season, search_title
from Backend.helper.anilist import fetch_anilist_data, get_anilist_titles
from themoviedb import aioTMDb
from Backend.config import Telegram
import Backend
from Backend.logger import LOGGER
from Backend.helper.encrypt import encode_string

# ----------------- Configuration -----------------
DELAY = 0
tmdb = aioTMDb(key=Telegram.TMDB_API, language="en-US", region="US")

# Cache dictionaries (per run)
IMDB_CACHE: dict = {}
TMDB_SEARCH_CACHE: dict = {}
TMDB_DETAILS_CACHE: dict = {}
EPISODE_CACHE: dict = {}

# Concurrency semaphore for external API calls
API_SEMAPHORE = asyncio.Semaphore(12)


# ----------------- Anime Caption Extraction -----------------
def extract_anime_title(caption: str) -> str:
    """
    Extract clean anime title from file caption/filename.
    Handles common anime caption formats:
      [animeshrine.xyz] S01E05 Title HDRip.mkv       ← title AFTER episode
      [SubsPlease] Title - 01 (1080p) [hash].mkv     ← title BEFORE episode
      [Erai-raws] Title - 01 [1080p] [Japanese].mkv
      Title S01E01 1080p.mkv
    
    Note: Captions may be multiline with language on next line.
    """
    if not caption:
        return ""
    
    # Take only the first line (language info like "Japanese" comes on next lines)
    text = caption.strip().split('\n')[0].strip()
    
    # Remove file extension
    text = re.sub(r'\.\w{2,4}$', '', text)
    
    # Remove fansub group tags like [SubsPlease], [Erai-raws], [animeshrine.xyz], etc.
    text = re.sub(r'^\[([^\]]+)\]\s*', '', text)
    
    # Remove hash tags like [ABCD1234] (8-char hex hashes at end)
    text = re.sub(r'\s*\[[0-9A-Fa-f]{6,8}\]\s*$', '', text)
    
    # Remove bracketed quality/codec/language tags: [1080p], [HEVC], [Japanese], etc.
    text = re.sub(r'\s*\[([^\]]*(?:(?:\d{3,4}p)|HEVC|x264|x265|AAC|FLAC|Japanese|English|Hindi|Multi|Dual|10bit|8bit)[^\]]*)\]\s*', ' ', text, flags=re.IGNORECASE)
    
    # Remove parenthesized quality tags: (1080p), (720p), (480p)
    text = re.sub(r'\s*\(\d{3,4}p\)\s*', ' ', text)
    
    # Remove @ mentions and channel tags
    text = re.sub(r'@\w+', '', text)
    
    # Try to detect: S01E05 Title ... pattern (title AFTER episode marker)
    # This is the user's primary format: [group] S01E05 Title Quality.ext
    after_ep_match = re.match(r'^S\d{1,2}E\d{1,3}\s+(.+)', text, re.IGNORECASE)
    if after_ep_match:
        text = after_ep_match.group(1).strip()
    else:
        # Handle " - XX" episode pattern (anime style: Title - 01, Title - 500)
        ep_match = re.match(r'^(.+?)\s*-\s*\d+', text)
        if ep_match:
            title_part = ep_match.group(1).strip()
            if len(title_part) > 2 and not title_part.isdigit():
                text = title_part
        else:
            # Remove S01E01 patterns from middle of text
            text = re.sub(r'\s*S\d{1,2}E\d{1,3}\s*', ' ', text, flags=re.IGNORECASE)
    
    # Remove standalone quality/codec tags not in brackets
    text = re.sub(r'\b(?:480p|720p|1080p|2160p|4K|HEVC|x264|x265|10bit|8bit|AAC|FLAC|WEBRip|WEB-DL|BluRay|BDRip|HDRip)\b', ' ', text, flags=re.IGNORECASE)
    
    # Remove language tags
    text = re.sub(r'\b(?:Japanese|English|Hindi|Multi|Dual[\s_-]*Audio)\b', ' ', text, flags=re.IGNORECASE)
    
    # Remove leftover season/episode markers
    text = re.sub(r'\s*(?:Season|S)\s*\d+\s*', ' ', text, flags=re.IGNORECASE)
    text = re.sub(r'\s*(?:Episode|E|EP)\s*\d+\s*', ' ', text, flags=re.IGNORECASE)
    
    # Remove remaining bracket content that looks like junk
    text = re.sub(r'\[([^\]]*)\]', '', text)
    text = re.sub(r'\(([^\)]*)\)', '', text)
    
    # Clean up whitespace, dots used as separators, underscores
    text = text.replace('.', ' ').replace('_', ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    text = text.strip('-').strip()
    
    return text


async def _get_anime_data(title: str, tmdb_genres: list) -> dict:
    """
    Get genres and tags for anime titles using AniList.
    Always try AniList first for anime content (Animation genre or no genres).
    AniList genres are always preferred and saved to DB.
    Returns: {"genres": [], "tags": []}
    """
    default_result = {"genres": [g.lower() for g in tmdb_genres], "tags": []}
    
    if not title:
        return default_result
    
    # Check if this might be anime (has Animation genre or no genres)
    is_anime = any(g.lower() == "animation" for g in tmdb_genres) or not tmdb_genres
    
    if is_anime:
        from Backend.helper.anilist import fetch_anilist_data
        anilist_data = await fetch_anilist_data(title)
        
        if anilist_data and (anilist_data.get("genres") or anilist_data.get("tags")):
            # If we found data, use it. If genres empty but tags found, use them + tmdb genres?
            # Let's stick to: if AniList has data, use it for genres. If not, fallback to TMDB.
            # Tags are additive.
            
            genres = anilist_data.get("genres") or [g.lower() for g in tmdb_genres]
            tags = anilist_data.get("tags") or []
            return {"genres": genres, "tags": tags}
    
    return default_result


# ----------------- Helpers -----------------
def format_tmdb_image(path: str, size="w500") -> str:
    if not path:
        return ""
    return f"https://image.tmdb.org/t/p/{size}{path}"

def get_tmdb_logo(images) -> str:
    if not images:
        return ""
    logos = getattr(images, "logos", None)
    if not logos:
        return ""
    for logo in logos:
        iso_lang = getattr(logo, "iso_639_1", None)
        file_path = getattr(logo, "file_path", None)
        if iso_lang == "en" and file_path:
            return format_tmdb_image(file_path, "w300")
    for logo in logos:
        file_path = getattr(logo, "file_path", None)
        if file_path:
            return format_tmdb_image(file_path, "w300")
    return ""
    

def format_imdb_images(imdb_id: str) -> dict:
    if not imdb_id:
        return {"poster": "", "backdrop": "", "logo": ""}
    return {
        "poster": f"https://images.metahub.space/poster/small/{imdb_id}/img",
        "backdrop": f"https://images.metahub.space/background/medium/{imdb_id}/img",
        "logo": f"https://images.metahub.space/logo/medium/{imdb_id}/img",
    }

def extract_default_id(url: str) -> str | None:
    # IMDb
    imdb_match = re.search(r'/title/(tt\d+)', url)
    if imdb_match:
        return imdb_match.group(1)

    # TMDb movie or TV
    tmdb_match = re.search(r'/((movie|tv))/(\d+)', url)
    if tmdb_match:
        return tmdb_match.group(3)

    return None


async def _search_imdb_with_fallback(title: str, type_: str) -> str | None:
    """
    Search IMDB with Japanese title fallback.
    1. Try English title
    2. If not found, get romaji title from AniList and try
    3. If still not found, get native (Japanese) title and try
    """
    # Step 1: Try with English title
    imdb_id = await safe_imdb_search(title, type_)
    if imdb_id:
        return imdb_id
    
    LOGGER.info(f"IMDB search failed for English title '{title}', trying AniList fallback...")
    
    # Step 2: Get alternative titles from AniList
    alt_titles = await get_anilist_titles(title)
    if not alt_titles:
        LOGGER.info(f"No AniList titles found for '{title}'")
        return None
    
    # Step 3: Try romaji title
    romaji = alt_titles.get("romaji", "")
    if romaji and romaji.lower() != title.lower():
        LOGGER.info(f"Trying romaji title: '{romaji}'")
        imdb_id = await safe_imdb_search(romaji, type_)
        if imdb_id:
            return imdb_id
    
    # Step 4: Try native (Japanese) title
    native = alt_titles.get("native", "")
    if native:
        LOGGER.info(f"Trying native Japanese title: '{native}'")
        imdb_id = await safe_imdb_search(native, type_)
        if imdb_id:
            return imdb_id
    
    # Step 5: Try synonyms
    for synonym in alt_titles.get("synonyms", [])[:3]:
        if synonym and synonym.lower() != title.lower():
            LOGGER.info(f"Trying synonym title: '{synonym}'")
            imdb_id = await safe_imdb_search(synonym, type_)
            if imdb_id:
                return imdb_id
    
    return None


async def _search_tmdb_with_fallback(title: str, type_: str, year=None):
    """
    Search TMDb with Japanese title fallback.
    Same logic as IMDB fallback but for TMDb API.
    Also filters for Animation genre.
    """
    # Step 1: Try English title
    result = await safe_tmdb_search(title, type_, year)
    if result:
        # Check if it has Animation genre
        genres = getattr(result, 'genre_ids', []) or []
        # TMDb Animation genre ID = 16
        if 16 in genres or not genres:
            return result
    
    LOGGER.info(f"TMDb search failed/non-animation for '{title}', trying AniList fallback...")
    
    # Step 2: Get alternative titles from AniList
    alt_titles = await get_anilist_titles(title)
    if not alt_titles:
        # If no AniList titles, return whatever we got (even non-animation)
        return result
    
    # Step 3: Try romaji title
    romaji = alt_titles.get("romaji", "")
    if romaji and romaji.lower() != title.lower():
        LOGGER.info(f"TMDb: Trying romaji title: '{romaji}'")
        r = await safe_tmdb_search(romaji, type_, year)
        if r:
            return r
    
    # Step 4: Try native title
    native = alt_titles.get("native", "")
    if native:
        LOGGER.info(f"TMDb: Trying native title: '{native}'")
        r = await safe_tmdb_search(native, type_, year)
        if r:
            return r
    
    # Return whatever we had from step 1 (could be None)
    return result


async def safe_imdb_search(title: str, type_: str) -> str | None:
    key = f"imdb::{type_}::{title}"
    if key in IMDB_CACHE:
        return IMDB_CACHE[key]
    try:
        async with API_SEMAPHORE:
            result = await search_title(query=title, type=type_, require_animation=True)
        imdb_id = result["id"] if result else None
        IMDB_CACHE[key] = imdb_id
        return imdb_id
    except Exception as e:
        LOGGER.warning(f"IMDb search failed for '{title}' [{type_}]: {e}")
        return None

async def safe_tmdb_search(title: str, type_: str, year=None):
    key = f"tmdb_search::{type_}::{title}::{year}"
    if key in TMDB_SEARCH_CACHE:
        return TMDB_SEARCH_CACHE[key]
    try:
        async with API_SEMAPHORE:
            if type_ == "movie":
                results = await tmdb.search().movies(query=title, year=year) if year else await tmdb.search().movies(query=title)
            else:
                results = await tmdb.search().tv(query=title)
        
        # Filter for Animation genre (genre_id 16 = Animation in TMDb)
        if results:
            animation_results = [
                r for r in results 
                if 16 in (getattr(r, 'genre_ids', []) or [])
            ]
            if animation_results:
                res = animation_results[0]
            else:
                # If no animation results, still return first one as fallback
                res = results[0]
        else:
            res = None
        
        TMDB_SEARCH_CACHE[key] = res
        return res
    except Exception as e:
        LOGGER.error(f"TMDb search failed for '{title}' [{type_}]: {e}")
        TMDB_SEARCH_CACHE[key] = None
        return None

async def _tmdb_movie_details(movie_id):
    if movie_id in TMDB_DETAILS_CACHE:
        return TMDB_DETAILS_CACHE[movie_id]
    try:
        async with API_SEMAPHORE:
            details = await tmdb.movie(movie_id).details(
                append_to_response="external_ids,credits"
            )
            images = await tmdb.movie(movie_id).images()
            details.images = images

        TMDB_DETAILS_CACHE[movie_id] = details
        return details
    except Exception as e:
        LOGGER.warning(f"TMDb movie details fetch failed for id={movie_id}: {e}")
        TMDB_DETAILS_CACHE[movie_id] = None
        return None


async def _tmdb_tv_details(tv_id):
    if tv_id in TMDB_DETAILS_CACHE:
        return TMDB_DETAILS_CACHE[tv_id]
    try:
        async with API_SEMAPHORE:
            details = await tmdb.tv(tv_id).details(
                append_to_response="external_ids,credits"
            )
            images = await tmdb.tv(tv_id).images()
            details.images = images
        TMDB_DETAILS_CACHE[tv_id] = details
        return details
    except Exception as e:
        LOGGER.warning(f"TMDb tv details fetch failed for id={tv_id}: {e}")
        TMDB_DETAILS_CACHE[tv_id] = None
        return None


async def _tmdb_episode_details(tv_id, season, episode):
    key = (tv_id, season, episode)
    if key in EPISODE_CACHE:
        return EPISODE_CACHE[key]
    try:
        async with API_SEMAPHORE:
            details = await tmdb.episode(tv_id, season, episode).details()
        EPISODE_CACHE[key] = details
        return details
    except Exception:
        EPISODE_CACHE[key] = None
        return None

# ----------------- Main Metadata -----------------
async def metadata(filename: str, channel: int, msg_id) -> dict | None:
    try:
        parsed = PTN.parse(filename)
    except Exception as e:
        LOGGER.error(f"PTN parsing failed for {filename}: {e}\n{traceback.format_exc()}")
        return None

    # Skip combined/invalid files
    if "excess" in parsed and any("combined" in item.lower() for item in parsed["excess"]):
        LOGGER.info(f"Skipping {filename}: contains 'combined'")
        return None

    # Skip split/multipart files
    multipart_pattern = compile(r'(?:part|cd|disc|disk)[s._-]*\d+(?=\.\w+$)', IGNORECASE)
    if multipart_pattern.search(filename):
        LOGGER.info(f"Skipping {filename}: seems to be a split/multipart file")
        return None

    title = parsed.get("title")
    season = parsed.get("season")
    episode = parsed.get("episode")
    year = parsed.get("year")
    quality = parsed.get("resolution")
    quality_type = parsed.get("quality")  # HDRip, WEBRip, BluRay, etc.
    
    # Prefer quality type (HDRip, WEBRip, etc.) over resolution if available
    if quality_type:
        quality = quality_type
    
    if isinstance(season, list) or isinstance(episode, list):
        LOGGER.warning(f"Invalid season/episode format for {filename}: {parsed}")
        return None
    if season is not None and episode is None:
        LOGGER.warning(f"Missing episode in {filename}: {parsed}")
        return None
    if not quality:
        LOGGER.warning(f"Skipping {filename}: No resolution (parsed={parsed})")
        return None
    
    # If PTN couldn't extract a title, try our anime-specific extraction
    if not title:
        title = extract_anime_title(filename)
        LOGGER.info(f"PTN failed to extract title, anime extraction got: '{title}' from: {filename}")
    
    if not title:
        LOGGER.info(f"No title parsed from: {filename} (parsed={parsed})")
        return None


    default_id = None
    try:
        default_id = extract_default_id(Backend.USE_DEFAULT_ID)
    except Exception:
        pass
    if not default_id:
        try:
            default_id = extract_default_id(filename)
        except Exception:
            pass

    data = {"chat_id": channel, "msg_id": msg_id}
    try:
        encoded_string = await encode_string(data)
    except Exception:
        encoded_string = None

    try:
        if season is not None and episode is not None:
            LOGGER.info(f"Fetching TV metadata: {title} S{season}E{episode}")
            return await fetch_tv_metadata(title, season, episode, encoded_string, year, quality, default_id)
        else:
            LOGGER.info(f"Fetching Movie metadata: {title} ({year})")
            return await fetch_movie_metadata(title, encoded_string, year, quality, default_id)
    except Exception as e:
        LOGGER.error(f"Error while fetching metadata for {filename}: {e}\n{traceback.format_exc()}")
        return None

# ----------------- TV Metadata -----------------
async def fetch_tv_metadata(title, season, episode, encoded_string, year=None, quality=None, default_id=None) -> dict | None:
    imdb_id = None
    tmdb_id = None
    imdb_tv = None
    imdb_ep = None
    use_tmdb = False

    # -------------------------------------------------------
    # 1. Handle default ID (IMDb / TMDb)
    # -------------------------------------------------------
    if default_id:
        default_id = str(default_id)
        if default_id.startswith("tt"):
            imdb_id = default_id
            use_tmdb = False
        elif default_id.isdigit():
            tmdb_id = int(default_id)
            use_tmdb = True

    # -------------------------------------------------------
    # 2. If no ID → Try IMDb search with Japanese fallback
    # -------------------------------------------------------
    if not imdb_id and not tmdb_id:
        imdb_id = await _search_imdb_with_fallback(title, "tvSeries")
        use_tmdb = not bool(imdb_id)

    # -------------------------------------------------------
    # 3. IMDb fetch (series + episode)
    # -------------------------------------------------------
    if imdb_id and not use_tmdb:
        try:
            # ----- series details
            if imdb_id in IMDB_CACHE:
                imdb_tv = IMDB_CACHE[imdb_id]
            else:
                async with API_SEMAPHORE:
                    imdb_tv = await get_detail(imdb_id=imdb_id, media_type="tvSeries")
                IMDB_CACHE[imdb_id] = imdb_tv

            # ----- episode details
            ep_key = f"{imdb_id}::{season}::{episode}"
            if ep_key in EPISODE_CACHE:
                imdb_ep = EPISODE_CACHE[ep_key]
            else:
                async with API_SEMAPHORE:
                    imdb_ep = await get_season(imdb_id=imdb_id, season_id=season, episode_id=episode)
                EPISODE_CACHE[ep_key] = imdb_ep

        except Exception as e:
            LOGGER.warning(f"IMDb TV fetch failed [{imdb_id}] → {e}")
            imdb_tv = None
            imdb_ep = None
            use_tmdb = True

    # -------------------------------------------------------
    # 4. Decide if TMDb required
    # -------------------------------------------------------
    must_use_tmdb = (
        use_tmdb or
        imdb_tv is None or
        imdb_tv == {}
    )

    # =======================================================
    #  5. TMDb MODE
    # =======================================================
    if must_use_tmdb:
        LOGGER.info(f"No valid IMDb TV data for '{title}' → using TMDb")

        # Search TMDb by title with fallback
        if not tmdb_id:
            tmdb_search = await _search_tmdb_with_fallback(title, "tv", year)
            if not tmdb_search:
                LOGGER.warning(f"No TMDb TV result for '{title}'")
                return None
            tmdb_id = tmdb_search.id

        # Fetch full TV show details
        tv = await _tmdb_tv_details(tmdb_id)
        if not tv:
            LOGGER.warning(f"TMDb TV details failed for id={tmdb_id}")
            return None

        # Fetch episode
        ep = await _tmdb_episode_details(tmdb_id, season, episode)

        # Cast list
        credits = getattr(tv, "credits", None) or {}
        cast_arr = getattr(credits, "cast", []) or []
        cast = [
            getattr(c, "name", None) or getattr(c, "original_name", None)
            for c in cast_arr
        ]

        # Runtime (prefer episode → series → empty)
        ep_runtime = getattr(ep, "runtime", None) if ep else None
        series_runtime = (
            tv.episode_run_time[0] if getattr(tv, "episode_run_time", None) else None
        )
        runtime_val = ep_runtime or series_runtime
        runtime = f"{runtime_val} min" if runtime_val else ""

        # Fetch anime data
        anime_data = await _get_anime_data(tv.name, [g.name for g in (tv.genres or [])])

        return {
            "tmdb_id": tv.id,
            "imdb_id": getattr(getattr(tv, "external_ids", None), "imdb_id", None),
            "title": tv.name,
            "year": getattr(tv.first_air_date, "year", 0) if getattr(tv, "first_air_date", None) else 0,
            "rate": getattr(tv, "vote_average", 0) or 0,
            "description": tv.overview or "",
            "poster": format_tmdb_image(tv.poster_path),
            "backdrop": format_tmdb_image(tv.backdrop_path, "original"),
            "logo": get_tmdb_logo(getattr(tv, "images", None)),
            "genres": anime_data.get("genres"),
            "tags": anime_data.get("tags"),
            "media_type": "tv",
            "cast": cast,
            "runtime": str(runtime),

            "season_number": season,
            "episode_number": episode,
            "episode_title": getattr(ep, "name", f"S{season}E{episode}") if ep else f"S{season}E{episode}",
            "episode_backdrop": format_tmdb_image(getattr(ep, "still_path", None), "original") if ep else "",
            "episode_overview": getattr(ep, "overview", "") if ep else "",
            "episode_released": (
                ep.air_date.strftime("%Y-%m-%dT05:00:00.000Z")
                if getattr(ep, "air_date", None)
                else ""
            ),

            "quality": quality,
            "encoded_string": encoded_string,
        }

    # =======================================================
    #  6. IMDb MODE — always use AniList genres
    # =======================================================
    imdb = imdb_tv or {}
    ep = imdb_ep or {}

    images = format_imdb_images(imdb_id)
    
    # Always get AniList genres for anime (instead of IMDB genres)
    imdb_genres = imdb.get("genre", [])
    anime_data = await _get_anime_data(imdb.get("title", title), imdb_genres)

    return {
        "tmdb_id": imdb.get("moviedb_id") or imdb_id.replace("tt", ""),
        "imdb_id": imdb_id,
        "title": imdb.get("title", title),
        "year": imdb.get("releaseDetailed", {}).get("year", 0),
        "rate": imdb.get("rating", {}).get("star", 0),
        "description": imdb.get("plot", ""),
        "poster": images["poster"],
        "backdrop": images["backdrop"],
        "logo": images["logo"],
        "cast": imdb.get("cast", []),
        "runtime": str(imdb.get("runtime") or ""),          
        "genres": anime_data.get("genres"),
        "tags": anime_data.get("tags"),
        "media_type": "tv",

        "season_number": season,
        "episode_number": episode,
        "episode_title": ep.get("title", f"S{season}E{episode}"),
        "episode_backdrop": ep.get("image", ""),
        "episode_overview": ep.get("plot", ""),
        "episode_released": str(ep.get("released", "")),

        "quality": quality,
        "encoded_string": encoded_string,
    }


# ----------------- Movie Metadata -----------------
async def fetch_movie_metadata(title, encoded_string, year=None, quality=None, default_id=None) -> dict | None:
    imdb_id = None
    tmdb_id = None
    imdb_details = None
    use_tmdb = False

    # -------------------------------------------------------
    # 1. PROCESS DEFAULT ID (tt = IMDb, digits = TMDb)
    # -------------------------------------------------------
    if default_id:
        default_id = str(default_id).strip()

        if default_id.startswith("tt"):
            imdb_id = default_id
            use_tmdb = False                       # force IMDb
        elif default_id.isdigit():
            tmdb_id = int(default_id)
            use_tmdb = True                        # force TMDb

    # -------------------------------------------------------
    # 2. IF NO DEFAULT ID → SEARCH IMDb WITH FALLBACK
    # -------------------------------------------------------
    if not imdb_id and not tmdb_id:
        imdb_id = await _search_imdb_with_fallback(
            f"{title} {year}" if year else title,
            "movie"
        )
        use_tmdb = not bool(imdb_id)

    # -------------------------------------------------------
    # 3. FETCH IMDb DETAILS (only if imdb_id exists)
    # -------------------------------------------------------
    if imdb_id and not use_tmdb:
        try:
            if imdb_id in IMDB_CACHE:
                imdb_details = IMDB_CACHE[imdb_id]
            else:
                async with API_SEMAPHORE:
                    imdb_details = await get_detail(
                        imdb_id=imdb_id,
                        media_type="movie"
                    )

                IMDB_CACHE[imdb_id] = imdb_details

        except Exception as e:
            LOGGER.warning(f"IMDb movie fetch failed [{title}] → {e}")
            imdb_details = None
            use_tmdb = True

    # -------------------------------------------------------
    # 4. DECIDE FINAL DATA SOURCE
    # -------------------------------------------------------
    must_use_tmdb = (
        use_tmdb or
        imdb_details is None or
        imdb_details == {}
    )

    # =======================================================
    #  5. TMDb MODE
    # =======================================================
    if must_use_tmdb:
        LOGGER.info(f"No valid IMDb data for '{title}' → using TMDb")

        # TMDb search if id unknown — with fallback
        if not tmdb_id:
            tmdb_result = await _search_tmdb_with_fallback(title, "movie", year)
            if not tmdb_result:
                LOGGER.warning(f"No TMDb movie found for '{title}'")
                return None
            tmdb_id = tmdb_result.id

        # Fetch TMDb details
        movie = await _tmdb_movie_details(tmdb_id)
        if not movie:
            LOGGER.warning(f"TMDb details failed for {tmdb_id}")
            return None

        # Cast extraction
        credits = getattr(movie, "credits", None) or {}
        cast_arr = getattr(credits, "cast", []) or []
        cast_names = [
            getattr(c, "name", None) or getattr(c, "original_name", None)
            for c in cast_arr
        ]

        runtime_val = getattr(movie, "runtime", None)
        runtime = f"{runtime_val} min" if runtime_val else ""

        # Fetch anime data
        anime_data = await _get_anime_data(movie.title, [g.name for g in (movie.genres or [])])

        return {
            "tmdb_id": movie.id,
            "imdb_id": getattr(movie.external_ids, "imdb_id", None),
            "title": movie.title,
            "year": getattr(movie.release_date, "year", 0) if getattr(movie, "release_date", None) else 0,
            "rate": getattr(movie, "vote_average", 0) or 0,
            "description": movie.overview or "",
            "poster": format_tmdb_image(movie.poster_path),
            "backdrop": format_tmdb_image(movie.backdrop_path, "original"),
            "logo": get_tmdb_logo(getattr(movie, "images", None)),
            "cast": cast_names,
            "runtime": str(runtime),
            "media_type": "movie",
            "genres": anime_data.get("genres"),
            "tags": anime_data.get("tags"),
            "quality": quality,
            "encoded_string": encoded_string,
        }

    # =======================================================
    #  6. IMDb MODE — always use AniList genres
    # =======================================================
    images = format_imdb_images(imdb_id)
    imdb = imdb_details or {}
    
    # Always get AniList genres for anime (instead of IMDB genres)
    # Always get AniList genres for anime (instead of IMDB genres)
    imdb_genres = imdb.get("genre", [])
    anime_data = await _get_anime_data(imdb.get("title", title), imdb_genres)

    return {
        "tmdb_id": imdb.get("moviedb_id") or imdb_id.replace("tt", ""),
        "imdb_id": imdb_id,
        "title": imdb.get("title", title),
        "year": imdb.get("releaseDetailed", {}).get("year", 0),
        "rate": imdb.get("rating", {}).get("star", 0),
        "description": imdb.get("plot", ""),
        "poster": images["poster"],
        "backdrop": images["backdrop"],
        "logo": images["logo"],
        "cast": imdb.get("cast", []),
        "runtime": str(imdb.get("runtime") or ""),
        "media_type": "movie",
        "genres": anime_data.get("genres"),
        "tags": anime_data.get("tags"),
        "quality": quality,
        "encoded_string": encoded_string,
    }
