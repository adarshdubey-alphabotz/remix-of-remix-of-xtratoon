
import httpx
import re
import asyncio
from difflib import SequenceMatcher
from typing import Optional, Dict, Any, List

BASE_URL = "https://v3-cinemeta.strem.io"

_client: Optional[httpx.AsyncClient] = None
_client_lock = asyncio.Lock()


async def _get_client() -> httpx.AsyncClient:
    global _client
    async with _client_lock:
        if _client is None or _client.is_closed:
            _client = httpx.AsyncClient(
                timeout=15.0,
                follow_redirects=True
            )
        return _client


def extract_first_year(year_string) -> int:
    if not year_string:
        return 0
    year_str = str(year_string)
    year_match = re.search(r'(\d{4})', year_str)
    if year_match:
        return int(year_match.group(1))
    return 0


def _title_similarity(query: str, result_title: str) -> float:
    """
    Compute title similarity score between query and result.
    Returns a float 0.0 to 1.0 — higher is better.
    Uses word-overlap + sequence matching for robust comparison.
    """
    if not query or not result_title:
        return 0.0
    
    q = query.lower().strip()
    r = result_title.lower().strip()
    
    # Exact match
    if q == r:
        return 1.0
    
    # SequenceMatcher ratio (handles partial matches well)
    seq_score = SequenceMatcher(None, q, r).ratio()
    
    # Word overlap score
    q_words = set(re.sub(r'[^\w\s]', '', q).split())
    r_words = set(re.sub(r'[^\w\s]', '', r).split())
    
    if q_words and r_words:
        overlap = len(q_words & r_words)
        word_score = overlap / max(len(q_words), len(r_words))
    else:
        word_score = 0.0
    
    # Combined score (weighted: sequence matching matters more)
    return (seq_score * 0.6) + (word_score * 0.4)


def _has_animation_genre(meta: dict) -> bool:
    """Check if a Cinemeta meta entry has Animation genre."""
    genres = meta.get("genres", []) or meta.get("genre", []) or []
    # genres can be a list of strings or sometimes a single string
    if isinstance(genres, str):
        genres = [genres]
    return any(g.lower() == "animation" for g in genres)


async def search_title(query: str, type: str, require_animation: bool = True) -> Optional[Dict[str, Any]]:
    """
    Query Cinemeta search endpoint for a title.
    type = 'tvSeries' or 'movie'
    
    If require_animation=True, filters results to only Animation genre entries
    and picks the best title match. This prevents anime from being matched to
    wrong live-action or unrelated animated content.
    """
    client = await _get_client()
    cinemeta_type = "series" if type == "tvSeries" else type
    url = f"{BASE_URL}/catalog/{cinemeta_type}/imdb/search={query}.json"
    try:
        resp = await client.get(url)
        if resp.status_code != 200:
            return None
        data = resp.json()
        if not data or 'metas' not in data or not data['metas']:
            return None
        
        metas = data['metas']
        
        if require_animation:
            # Filter to only animation entries
            animation_metas = []
            for meta in metas:
                meta_id = meta.get('imdb_id', meta.get('id', ''))
                # Try to check genres from search results
                meta_genres = meta.get('genres', []) or []
                
                if meta_genres:
                    # If genres available in search results, check directly
                    if any(g.lower() == 'animation' for g in meta_genres):
                        animation_metas.append(meta)
                else:
                    # If no genres in search, fetch details to check
                    if meta_id:
                        detail = await get_detail(meta_id, type)
                        
                        # Get genres from detail, if any
                        detail_genres = (detail.get('genre', []) or []) if detail else []
                        
                        if detail_genres:
                            if any(g.lower() == 'animation' for g in detail_genres):
                                animation_metas.append(meta)
                        else:
                            # If NO genres found even in details, check title similarity
                            # This handles cases where Cinemeta hasn't populated genres for new anime
                            name = meta.get('name', '')
                            if _title_similarity(query, name) >= 0.7:
                                animation_metas.append(meta)
            
            if not animation_metas:
                # No animation results found
                return None
            
            # Pick the best match by title similarity
            best_meta = None
            best_score = -1.0
            for meta in animation_metas:
                name = meta.get('name', '')
                score = _title_similarity(query, name)
                if score > best_score:
                    best_score = score
                    best_meta = meta
            
            if best_meta:
                return {
                    'id': best_meta.get('imdb_id', best_meta.get('id', '')),
                    'type': type,
                    'title': best_meta.get('name', ''),
                    'year': best_meta.get('releaseInfo', ''),
                    'poster': best_meta.get('poster', '')
                }
            return None
        else:
            # No animation filter — just take the first result (legacy behavior)
            meta = metas[0]
            return {
                'id': meta.get('imdb_id', meta.get('id', '')),
                'type': type,
                'title': meta.get('name', ''),
                'year': meta.get('releaseInfo', ''),
                'poster': meta.get('poster', '')
            }
    except Exception:
        return None


async def get_detail(imdb_id: str, media_type: str) -> Optional[Dict[str, Any]]:
    client = await _get_client()
    cinemeta_type = "series" if media_type in ["tvSeries", "tv"] else "movie"

    try:
        url = f"{BASE_URL}/meta/{cinemeta_type}/{imdb_id}.json"
        resp = await client.get(url)

        if resp.status_code != 200:
            return None

        data = resp.json()
        meta = data.get("meta")
        if not meta:
            return None

        # ---- Extract year ----
        year_value = 0
        for field in ["year", "releaseInfo", "released"]:
            if meta.get(field):
                year_value = extract_first_year(meta[field])
                if year_value:
                    break

        return {
            "id": meta.get("imdb_id") or meta.get("id"),
            "moviedb_id": meta.get("moviedb_id"),
            "type": meta.get("type", media_type),
            "title": meta.get("name", ""),
            "plot": meta.get("description", ""),
            "genre": meta.get("genres") or meta.get("genre", []),
            "releaseDetailed": {"year": year_value},
            "rating": {"star": float(meta.get("imdbRating", 0) or 0)},
            "poster": meta.get("poster", ""),
            "background": meta.get("background", ""),
            "logo": meta.get("logo", ""),
            "runtime": meta.get("runtime") or 0,
            "director": meta.get("director", []),
            "cast": meta.get("cast", []),
            "videos": meta.get("videos", [])
        }

    except Exception:
        return None


async def get_season(imdb_id: str, season_id: int, episode_id: int) -> Optional[Dict[str, Any]]:
    """
    Return episode meta for a specific season/episode using Cinemeta series endpoint.
    """
    client = await _get_client()
    try:
        url = f"{BASE_URL}/meta/series/{imdb_id}.json"
        resp = await client.get(url)
        if resp.status_code != 200:
            return None
        data = resp.json()
        if 'meta' in data and 'videos' in data['meta']:
            for video in data['meta']['videos']:
                if (str(video.get('season', '')) == str(season_id) and
                        str(video.get('episode', '')) == str(episode_id)):
                    return {
                        'title': video.get('title', f'Episode {episode_id}'),
                        'no': str(episode_id),
                        'season': str(season_id),
                        'image': video.get('thumbnail', ''),
                        'plot': video.get('overview', ''),
                        'released': video.get('released', '')
                    }
        return None
    except Exception:
        return None
