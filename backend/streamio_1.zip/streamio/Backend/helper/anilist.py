import aiohttp
import asyncio
from Backend.logger import LOGGER

ANILIST_URL = "https://graphql.anilist.co"
ANILIST_CACHE = {}
ANILIST_TITLE_CACHE = {}
API_SEMAPHORE = asyncio.Semaphore(5)


async def fetch_anilist_data(title: str) -> dict:
    """
    Fetch genres and tags from AniList for anime titles.
    Returns dict {'genres': [], 'tags': []}
    """
    if not title:
        return {"genres": [], "tags": []}
    
    # Check cache first
    cache_key = title.lower().strip()
    if cache_key in ANILIST_CACHE:
        return ANILIST_CACHE[cache_key]
    
    query = """
    query ($search: String) {
        Media(search: $search, type: ANIME) {
            title {
                romaji
                english
            }
            genres
            tags {
                name
                rank
                isMediaSpoiler
            }
        }
    }
    """
    
    try:
        async with API_SEMAPHORE:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    ANILIST_URL,
                    json={"query": query, "variables": {"search": title}},
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        
                        # Check for errors in response
                        if "errors" in data:
                            LOGGER.warning(f"AniList API error for '{title}': {data['errors']}")
                            ANILIST_CACHE[cache_key] = {"genres": [], "tags": []}
                            return {"genres": [], "tags": []}
                        
                        media = data.get("data", {}).get("Media")
                        if media:
                            raw_genres = media.get("genres", [])
                            # Process genres: split on & and flatten
                            genres = []
                            for g in raw_genres:
                                if "&" in g:
                                    # Split "Action & Adventure" -> ["action", "adventure"]
                                    parts = [part.strip().lower() for part in g.split("&")]
                                    genres.extend(parts)
                                else:
                                    genres.append(g.lower())
                            
                            # Process tags
                            raw_tags = media.get("tags", [])
                            tags = []
                            for t in raw_tags:
                                # Filter out heavy spoilers or low rank if needed, but for now take all relevant
                                # Maybe filter by rank > 60?
                                if not t.get("isMediaSpoiler") and t.get("rank", 0) >= 50:
                                    tags.append(t.get("name"))
                            
                            result = {"genres": genres, "tags": tags}
                            ANILIST_CACHE[cache_key] = result
                            LOGGER.info(f"AniList data for '{title}': {result}")
                            return result
                        else:
                            LOGGER.warning(f"AniList no media found for '{title}', response: {data}")
                    elif resp.status == 429:
                        LOGGER.warning(f"AniList rate limited, retrying after delay...")
                        await asyncio.sleep(2)
                        return await fetch_anilist_data(title)
                    else:
                        LOGGER.warning(f"AniList API returned status {resp.status} for '{title}'")
    except asyncio.TimeoutError:
        LOGGER.warning(f"AniList request timed out for '{title}'")
    except Exception as e:
        LOGGER.warning(f"AniList fetch failed for '{title}': {e}")
    
    ANILIST_CACHE[cache_key] = {"genres": [], "tags": []}
    return {"genres": [], "tags": []}


async def search_anilist_by_title(title: str) -> dict | None:
    """
    Search AniList for anime by title.
    Returns media info dict or None if not found.
    """
    if not title:
        return None
    
    query = """
    query ($search: String) {
        Media(search: $search, type: ANIME) {
            id
            title {
                romaji
                english
                native
            }
            synonyms
            genres
            description(asHtml: false)
            coverImage {
                large
            }
            bannerImage
            averageScore
            seasonYear
        }
    }
    """
    
    try:
        async with API_SEMAPHORE:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    ANILIST_URL,
                    json={"query": query, "variables": {"search": title}},
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data.get("data", {}).get("Media")
    except Exception as e:
        LOGGER.warning(f"AniList search failed for '{title}': {e}")
    
    return None


async def get_anilist_titles(title: str) -> dict | None:
    """
    Get all title variants from AniList for fallback searches.
    Returns dict with english, romaji, native (Japanese), and synonyms.
    Uses cache to avoid repeated API calls.
    """
    if not title:
        return None
    
    cache_key = title.lower().strip()
    if cache_key in ANILIST_TITLE_CACHE:
        return ANILIST_TITLE_CACHE[cache_key]
    
    media = await search_anilist_by_title(title)
    if not media:
        ANILIST_TITLE_CACHE[cache_key] = None
        return None
    
    titles = media.get("title", {})
    result = {
        "english": titles.get("english") or "",
        "romaji": titles.get("romaji") or "",
        "native": titles.get("native") or "",
        "synonyms": media.get("synonyms", []),
    }
    
    ANILIST_TITLE_CACHE[cache_key] = result
    LOGGER.info(f"AniList titles for '{title}': english='{result['english']}', romaji='{result['romaji']}', native='{result['native']}'")
    return result
