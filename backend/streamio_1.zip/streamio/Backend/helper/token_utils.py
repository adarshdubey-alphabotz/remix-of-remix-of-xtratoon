import hmac
import hashlib
import time
import os
import secrets
from datetime import datetime, timezone

# Secret key for signing tokens
SECRET_KEY = os.getenv("TOKEN_SECRET", "a7f8c9d2e1b4a5f6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0")
TOKEN_EXPIRY = 2 * 60 * 60  # 2 hours in seconds


def generate_token(file_id: str, expires_at: int = None) -> str:
    """
    Generate a 64-character token with random ID + expiry + signature.
    IMPORTANT: Call store_token_async() separately to persist to MongoDB.
    
    Format: {random_id_24chars}{expires_hex_8chars}{signature_32chars} = 64 chars
    
    Returns: (token, token_id, expires_at) for storage
    """
    if expires_at is None:
        expires_at = int(time.time()) + TOKEN_EXPIRY
    
    # Generate random 24-char token ID (12 bytes = 24 hex chars)
    token_id = secrets.token_hex(12)
    
    # Convert expiry to 8-char hex
    expires_hex = format(expires_at, '08x')
    
    # Create signature over token_id + expiry
    data = f"{token_id}:{expires_at}"
    signature = hmac.new(
        SECRET_KEY.encode(),
        data.encode(),
        hashlib.sha256
    ).hexdigest()[:32]
    
    # Total: 24 + 8 + 32 = 64 characters
    token = f"{token_id}{expires_hex}{signature}"
    
    # Store in pending list for async storage
    _pending_tokens[token_id] = {
        'file_id': file_id,
        'expires_at': expires_at
    }
    
    return token


# Pending tokens waiting to be stored in MongoDB
_pending_tokens = {}


async def store_pending_tokens(db):
    """Store all pending tokens to MongoDB. Call this after generating tokens."""
    global _pending_tokens
    for token_id, data in list(_pending_tokens.items()):
        expires_dt = datetime.fromtimestamp(data['expires_at'], tz=timezone.utc)
        await db.store_token(token_id, data['file_id'], expires_dt)
    _pending_tokens.clear()


def parse_token(token: str) -> tuple[str, int, str]:
    """Parse token into components. Returns (token_id, expires_at, signature)."""
    if not token or len(token) != 64:
        raise ValueError("Invalid token format")
    
    token_id = token[:24]
    expires_hex = token[24:32]
    signature = token[32:64]
    expires_at = int(expires_hex, 16)
    
    return token_id, expires_at, signature


def verify_token_signature(token: str) -> tuple[bool, str, int]:
    """
    Verify token signature and expiry (stateless check).
    Returns (is_valid, token_id, expires_at).
    Does NOT check if token exists in DB - use verify_token_async for full check.
    """
    if not token or len(token) != 64:
        return False, "", 0
    
    try:
        token_id, expires_at, signature = parse_token(token)
        
        # Check expiry first
        if time.time() > expires_at:
            return False, "", 0  # Token expired
        
        # Verify signature
        data = f"{token_id}:{expires_at}"
        expected_sig = hmac.new(
            SECRET_KEY.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()[:32]
        
        if not hmac.compare_digest(signature, expected_sig):
            return False, "", 0  # Invalid signature
        
        return True, token_id, expires_at
        
    except (ValueError, TypeError):
        return False, "", 0


async def verify_token_async(token: str, db) -> tuple[bool, str]:
    """
    Fully verify token and retrieve file_id from MongoDB.
    Returns (is_valid, file_id) tuple.
    """
    # First check signature
    is_valid, token_id, expires_at = verify_token_signature(token)
    if not is_valid:
        return False, ""
    
    # Check pending tokens first (just generated, not yet stored)
    if token_id in _pending_tokens:
        return True, _pending_tokens[token_id]['file_id']
    
    # Look up in MongoDB
    file_id = await db.get_token_file_id(token_id)
    if not file_id:
        return False, ""
    
    return True, file_id


# Sync wrapper for verify_token (uses pending tokens only, for Telegram bot)
def verify_token(token: str) -> tuple[bool, str]:
    """
    Verify token using pending tokens cache.
    For full DB verification, use verify_token_async.
    """
    is_valid, token_id, _ = verify_token_signature(token)
    if not is_valid:
        return False, ""
    
    if token_id in _pending_tokens:
        return True, _pending_tokens[token_id]['file_id']
    
    # Can't verify without async DB access
    return False, ""


def get_expiry_time(token: str) -> int:
    """Get expiry timestamp from token."""
    if not token or len(token) < 32:
        return 0
    try:
        return int(token[24:32], 16)
    except ValueError:
        return 0
